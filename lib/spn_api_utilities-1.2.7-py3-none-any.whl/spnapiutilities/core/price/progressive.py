from spnapiutilities.core.price.price_model import PriceModel


class Progressive:
    def __init__(self, price_model: PriceModel):
        self.price_model: PriceModel = price_model
        self.total_hours: int = self.price_model.get_total_hours()
        self.first_price = self.price_model.get_start_price()
        self.next_hours = self.price_model.get_next_hours()
        self.initial_time = self.price_model.get_start_hours()
        self.total_hours = self.price_model.get_total_hours()
        self.next_price = self.price_model.get_next_price()

    def execute(self):
        if self.total_hours <= self.initial_time:
            amount = self.first_price
            return amount

        if self.total_hours > self.next_hours:
            left_hours = self.total_hours - self.initial_time
            if self.next_hours > 1:
                left_hours = int(left_hours / self.next_hours)

            amount = self.first_price + (self.next_price * left_hours)

        return amount
