from spnapiutilities.helpers.datetime_diff_helper import DateTimeDifferenceHelper

class PriceModel:
    def __init__(self):
        self.__id: str = None
        self.__price: int = 0
        self.__price_type: str = None

        self.__discount: int = 0
        self.__point: int = 0

        self.__count_progressive_type: str = None

        self.__grace_period: int = 0

        self.__start_hours: int = None
        self.__next_hours: int = None
        self.__max_hours = 24

        self.__start_price: int = 0
        self.__next_price: int = 0
        self.__max_price: int = 0

        self.__overstay_price: int = 0
        self.__overstay_affected_user: str = None
        self.__overstay_product_member: str = None
        self.__overstay_parameter: str = None
        self.__overstay_start: str = None
        self.__overstay_end: str = None
        self.__overstay_duration: int = 0   

        self.__period_data: list = None

        self.__membership_daily_transaction: int = False
        self.__timezone: str = 'Asia/Jakarta'
        
        self.__time_in = 0
        self.__time_out = 0
        self.__total_hours_before_round_up = 0
        self.__total_hours = 0
        self.__total_minutes = 0
        
        self.__is_membership = False
        
        
    def set_is_membership(self, is_membership: bool):
        self.__is_membership = is_membership
        
    def get_is_membership(self):
        return self.__is_membership
        
    def set_time_in(self, time_in: int):
        self.__time_in = time_in
        
    def get_time_in(self):
        return self.__time_in
    
    def set_time_out(self, time_out: int):
        self.__time_out = time_out
        
    def get_time_out(self):
        return self.__time_out
    
    def set_total_hours(self):
        count_hours = DateTimeDifferenceHelper.count_hours_with_data(self.__time_in, self.__time_out)
        self.__total_hours = int(count_hours["round_up"])
        self.__total_hours_before_round_up = count_hours["real_count"]
        self.__total_minutes = int(count_hours['minutes'])
        
    def get_total_hours(self):
        return self.__total_hours
    
    def get_total_minutes(self):
        return self.__total_minutes
        
    def get_total_hours_before_round_up(self):
        return self.__total_hours_before_round_up

    def set_membership_daily_transaction(self, membership_daily_transaction: bool):
        self.__membership_daily_transaction = membership_daily_transaction

    def get_membership_daily_transaction(self):
        return self.__membership_daily_transaction

    def set_discount(self, discount: int):
        self.__discount = discount

    def get_discount(self):
        return self.__discount

    def set_point(self, point: int):
        self.__point = point

    def get_point(self):
        return self.__point

    def set_overstay_price(self, overstay_price: int):
        self.__overstay_price = overstay_price

    def get_overstay_price(self):
        return self.__overstay_price

    def set_overstay_affected_user(self, overstay_affected_user: str):
        self.__overstay_affected_user = overstay_affected_user

    def get_overstay_affected_user(self):
        return self.__overstay_affected_user

    def set_overstay_product_member(self, overstay_product_member: str):
        self.__overstay_product_member = overstay_product_member

    def get_overstay_product_member(self):
        return self.__overstay_product_member

    def set_overstay_parameter(self, overstay_parameter: str):
        self.__overstay_parameter = overstay_parameter

    def get_overstay_parameter(self):
        return self.__overstay_parameter

    def set_overstay_start(self, overstay_start: str):
        self.__overstay_start = overstay_start

    def get_overstay_start(self):
        return self.__overstay_start

    def set_overstay_end(self, overstay_end: str):
        self.__overstay_end = overstay_end

    def get_overstay_end(self):
        return self.__overstay_end

    def set_overstay_duration(self, overstay_duration: int):
        self.__overstay_duration = overstay_duration

    def get_overstay_duration(self):
        return self.__overstay_duration

    def set_start_hours(self, start_hours: int):
        self.__start_hours = start_hours

    def get_start_hours(self):
        return self.__start_hours

    def set_next_hours(self, next_hours: int):
        self.__next_hours = next_hours

    def get_next_hours(self):
        return self.__next_hours

    def set_max_hours(self, max_hours: int):
        self.__max_hours = max_hours

    def get_max_hours(self):
        return self.__max_hours

    def set_start_price(self, start_price: int):
        self.__start_price = start_price

    def get_start_price(self):
        return self.__start_price

    def set_next_price(self, next_price: int):
        self.__next_price = next_price

    def get_next_price(self):
        return self.__next_price

    def set_max_price(self, max_price: int):
        self.__max_price = max_price

    def get_max_price(self):
        return self.__max_price

    def set_id(self, id: str):
        self.__id = id

    def get_id(self):
        return self.__id

    def set_price(self, price: int):
        self.__price = price

    def get_price(self):
        return self.__price

    def set_price_type(self, price_type: str):
        self.__price_type = price_type

    def get_price_type(self):
        return self.__price_type

    def set_count_type(self, count_type: str):
        self.__count_type = count_type

    def get_count_type(self):
        return self.__count_type

    def set_overstay_type(self, overstay_type: str):
        self.__overstay_type = overstay_type

    def get_overstay_type(self):
        return self.__overstay_type

    def set_grace_period(self, grace_period: int):
        self.__grace_period = grace_period

    def get_grace_period(self):
        return self.__grace_period

    def set_next_price(self, next_price: int):
        self.__next_price = next_price

    def get_next_price(self):
        return self.__next_price

    def set_period_data(self, period_data: str):
        self.__period_data = period_data

    def get_period_data(self):
        return self.__period_data

    def set_timezone(self, timezone: str):
        self.__timezone = timezone

    def get_timezone(self):
        return self.__timezone

    def set_overstay_progressive_time_start(self, overstay_progressive_time_start: int):
        self.__overstay_progressive_time_start = overstay_progressive_time_start

    def get_overstay_progressive_time_start(self):
        return self.__overstay_progressive_time_start

    def set_overstay_progressive_time_next(self, overstay_progressive_time_next: int):
        self.__overstay_progressive_time_next = overstay_progressive_time_next

    def get_overstay_progressive_time_next(self):
        return self.__overstay_progressive_time_next

    def set_overstay_start_price(self, overstay_start_price: int):
        self.__overstay_start_price = overstay_start_price

    def get_overstay_start_price(self):
        return self.__overstay_start_price

    def set_overstay_next_price(self, overstay_next_price: int):
        self.__overstay_next_price = overstay_next_price

    def get_overstay_next_price(self):
        return self.__overstay_next_price

    def set_overstay_max_hours(self, overstay_max_hours: int):
        self.__overstay_max_hours = overstay_max_hours

    def get_overstay_max_hours(self):
        return self.__overstay_max_hours

    def set_overstay_max_price(self, overstay_max_price: int):
        self.__overstay_max_price = overstay_max_price

    def get_overstay_max_price(self):
        return self.__overstay_max_price