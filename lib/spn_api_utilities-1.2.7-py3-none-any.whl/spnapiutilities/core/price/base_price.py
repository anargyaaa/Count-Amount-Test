from abc import ABC, abstractmethod

def BasePrice(ABC):
    def __init__(self):
        pass
    
    @abstractmethod
    def execute(self):
        pass
    