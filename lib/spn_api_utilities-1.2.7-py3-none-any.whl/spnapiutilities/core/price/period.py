from datetime import timedelta

import pytz
from spnapiutilities.core.price.price_model import PriceModel

from spnapiutilities.helpers.datetime_helper import DateTimeHelper

"""period_data sample data
[
    {"start": 6, "end": 19, "price": 10000},
    {"start": 19, "end": 22, "price": 20000},
    {"start": 22, "end": 30, "price": 30000},
]
"""


class Period:
    def __init__(self, price_model: PriceModel):
        self.price_model: PriceModel = price_model
        self.total_hours: int = self.price_model.get_total_hours()
        self.time_in: int = self.price_model.get_time_in()
        self.time_out: int = self.price_model.get_time_out()
        self.datetime_helper = DateTimeHelper

    def execute(self):
        if self.price_model.get_total_hours_before_round_up() < self.price_model.get_start_hours():
            return self.price_model.get_start_price()

        amount = 0
        max_amount = 0

        timezone = None
        try:
            timezone = pytz.timezone(self.price_model.get_timezone())
        except:
            # NOTE Test case perlu utc karena libnya tapi real case harus pakai time asli
            print('Timezone not found, possibly because of testing')

        time_in = self.datetime_helper.get_datetime_fromtimestamp(
            timestamp=self.time_in, zone=timezone)
        time_out = self.datetime_helper.get_datetime_fromtimestamp(
            timestamp=self.time_out, zone=timezone)

        time_in_period = {}
        time_out_period = {}
        period_index = []

        day_diff = (time_out - time_in).days
        # date_diff = (time_out.date() - time_in.date()).days # NOTE from testing, this part can be removed -Rei

        biggest = {"start": 0, "end": 0, "index": 0, "price": 0}

        sorted_period = sorted(
            self.price_model.get_period_data(), key=lambda x: x["start"])
        # normal period base on entry and exit
        for index, period in enumerate(sorted_period):
            start = period["start"] % 24
            end = period["end"] % 24
            price = period["price"]
            max_amount = max(max_amount, price)
            period_index.append(index)

            if biggest["end"] < period["end"]:
                biggest["end"] = period["end"]
                biggest["start"] = period["start"]
                biggest["index"] = index
                biggest["price"] = price

            time_in_start = time_in.replace(
                hour=start, minute=0, second=0, microsecond=0)
            time_in_end = time_in.replace(
                hour=end, minute=0, second=0, microsecond=0)

            time_out_start = time_out.replace(
                hour=start, minute=0, second=0, microsecond=0)
            time_out_end = time_out.replace(
                hour=end, minute=0, second=0, microsecond=0)

            if period["start"] >= 24:
                time_in_start += timedelta(days=1)
                time_out_start += timedelta(days=1)

            if period["end"] >= 24:
                time_in_end += timedelta(days=1)
                time_out_end += timedelta(days=1)

            if time_in_start.timestamp() <= time_in.timestamp() <= time_in_end.timestamp():
                time_in_period["period"] = index
                time_in_period["price"] = price

            if time_out_start.timestamp() <= time_out.timestamp() <= time_out_end.timestamp():
                time_out_period["period"] = index
                time_out_period["price"] = price

        # check biggest period to include yesterday biggest period for time_in
        if not time_in_period:
            start = biggest["start"] % 24
            end = biggest["end"] % 24

            time_in_start = time_in.replace(
                hour=start, minute=0, second=0, microsecond=0) - timedelta(days=1)
            time_in_end = time_in.replace(
                hour=end, minute=0, second=0, microsecond=0) - timedelta(days=1)

            if period["start"] >= 24:
                time_in_start += timedelta(days=1)

            if period["end"] >= 24:
                time_in_end += timedelta(days=1)

            if time_in_start.timestamp() < time_in.timestamp() <= time_in_end.timestamp():
                time_in_period["period"] = biggest["index"]
                time_in_period["price"] = biggest["price"]

        # check biggest period to include yesterday biggest period
        if not time_out_period:
            start = biggest["start"] % 24
            end = biggest["end"] % 24

            time_out_start = time_out.replace(
                hour=start, minute=0, second=0, microsecond=0) - timedelta(days=1)
            time_out_end = time_out.replace(
                hour=end, minute=0, second=0, microsecond=0) - timedelta(days=1)

            if period["start"] >= 24:
                time_out_start += timedelta(days=1)

            if period["end"] >= 24:
                time_out_end += timedelta(days=1)

            if time_out_start.timestamp() < time_out.timestamp() <= time_out_end.timestamp():
                time_out_period["period"] = biggest["index"]
                time_out_period["price"] = biggest["price"]

        amount = time_out_period["price"]
        # ubah jadi before round untuk case 23 <= x < 24
        if not self.price_model.get_total_hours_before_round_up() < 24:
            multiplier = day_diff
            amount += max_amount * multiplier

        # Jika parking kurang dari 24 jam, validasi period kapan dia masuk dan keluar
        time_in_period_in_last_period = time_in_period["period"] == period_index[-1]
        time_in_period_bigger_than_time_out_period = time_in_period["period"] > time_out_period["period"]
        time_in_period_and_time_out_period_in_last_period = time_in_period["period"] == time_out_period["period"] == period_index[-1]
        if time_in_period_in_last_period or time_in_period_bigger_than_time_out_period:
            if time_in_period_and_time_out_period_in_last_period:
                return amount
            amount += max_amount

        return amount
