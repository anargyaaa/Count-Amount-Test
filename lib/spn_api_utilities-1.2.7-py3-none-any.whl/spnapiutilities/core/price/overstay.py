from spnapiutilities.core.price.price_model import PriceModel
from spnapiutilities.constants.price_constant import OverstayCountType, OverstayParameter
from spnapiutilities.core.price.progressive import Progressive
import math
from datetime import datetime, timedelta

class Overstay:
    def __init__(self, price_model: PriceModel):
        self.price_model: PriceModel = price_model
        self.is_membership: bool = self.price_model.get_is_membership()
        self.time_in: int = self.price_model.get_time_in()
        self.time_out: int = self.price_model.get_time_out()
        self.overstay_start = 0
        self.overstay_end = 0

    def execute(self) -> dict:
        total_overstay_time = 0

        payload = {
            "amount": 0,
            "price": 0,
            "total_days": 0
        }

        """
        We check the difference of total hours using floor because we want to round down the float.
        E.g: 2.45 to 2 because overstay is counted when the time is passing the range, we don't have to round up the hours.
        It's different between the park counting amount, for the overstay we have to round down.
        Confirmed by Natasha as Product Manager at 2022-12-08 14:01:00 on Slack.
        """
        difference = self.time_out - self.time_in
        total_hours = math.floor(difference / 1000 / 60 / 60)
        overstay_hours = self.mapping_overstay_hours()

        if len(overstay_hours) > 0 and self.price_model.get_overstay_parameter() == OverstayParameter.CURFEW.value:
            total_overstay_time = self.count_curfew_days(
                total_hours=total_hours, overstay_hours=overstay_hours)

        elif total_hours >= self.price_model.get_overstay_duration() and self.price_model.get_overstay_parameter() == OverstayParameter.DURATION.value:
            total_overstay_time = self.count_duration_days(
                total_hours=total_hours)

        amount, price = self.count_overstay_fee(
            total_overstay_time=total_overstay_time)

        payload["price"] = price
        payload["amount"] = amount
        payload["total_days"] = total_overstay_time
        return payload

    def mapping_overstay_hours(self):
        self.overstay_start = self.price_model.get_overstay_start()
        self.overstay_end = self.price_model.get_overstay_end()

        if not self.overstay_start or not self.overstay_end:
            return []

        """We split the minutes so we get only hours. E.g: 23:00 -> 23"""
        self.overstay_start = self.overstay_start.split(":")[0]
        self.overstay_end = self.overstay_end.split(":")[0]

        """
        We prepare the start array so we could divide the start from n until 24 (hours)"""
        start_array = []

        """
        We prepare the end array so we could divide the start from 0 until n + 1 (hours). Why n+1?
        Example: end time in 09:00, in order to make sure the range looping hit the 9, so we should put 10 (9+1)
        """
        end_array = []

        if self.overstay_start < self.overstay_end:
            start_array = [i for i in range(int(self.overstay_start), 24)]
            end_array = [i for i in range(0, int(self.overstay_end) + 1)]

            """Merge the array so we get something like [23, 0, 1, 2]"""
            overstay_hours = [x for x in start_array if x in end_array]
            # overstay_hours = start_array + end_array
            # overstay_hours.pop()
        else:
            '''
            This is used when overstay_start > overstay_end
            '''
            start_array = [i for i in range(0, int(self.overstay_start))]
            end_array = [i for i in range(int(self.overstay_end) + 1, 24)]

            start_set = set(start_array)
            end_set = set(end_array)
            overstay_hours = list(start_set.symmetric_difference(end_set))
            # Can't use pop since it is reverse
            # overstay_hours.remove(int(self.overstay_end))

        return overstay_hours

    def count_curfew_days(self, total_hours: int, overstay_hours: list) -> int:
        """
        We get the real days by divide-it into 24 so we don't have to think about the left hours.
        We also assume the 24 hours is always passing the overstay period.
        As example:
        Range 23:00-01:00
        In: 2022-08-09 19:30:00
        Out: 2022-08-10 20:00:00

        It's gonna be 1 day overstay because it already passed the range isn't it?
        """
        total_overstay_days = 0
        days = int(total_hours / 24)

        """We add one hours to the time out because we want to check the left hours difference for checking the overstay"""
        result = datetime.fromtimestamp(
            int(self.time_out) / 1000.0) + timedelta(hours=1)

        '''Get the hour from time_in and time_out to be compared with the overstay hours array'''
        check_in = datetime.fromtimestamp(
            int(self.time_in) / 1000.0)
        check_out = datetime.fromtimestamp(
            int(self.time_out) / 1000.0)
        check_array = [int(check_in.strftime("%H")),
                       int(check_out.strftime("%H"))]

        """We check the real days and add into the total overstay days"""
        if days > 0:
            total_overstay_days += days
            if self.price_model.get_overstay_type():
                """
                if progressive, then we count the length of the overstay hours
                and multiply it with the days. We override the total overstay days.
                """
                total_overstay_days = len(overstay_hours) * days

        """
        All we have to do is to check the left hours of the overstay.
        As example: You have 50 hours, so you have to count the last 2 hours (50-48), is it passing the overstay period or not.
        """
        left_hours = (total_hours % 24)

        if bool(set(check_array) & set(overstay_hours)) and total_hours <= 24:
            if self.price_model.get_overstay_type():
                total_overstay_days = self.calculate_overstay_hours(overstay_hours, check_array, total_hours)
            else:
                '''
                Check if the time in and time out 'Hour' exists in overstay hours array.
                '''
                for hour in check_array:
                    if hour in overstay_hours:
                        # Skip counting if the user enters exactly when overstay ends
                        if hour == int(check_in.strftime("%H")) and hour == int(self.overstay_end):
                            continue
                        else:
                            # For non-progressive overstay types, count each occurrence as one day of overstay
                            total_overstay_days += 1
                        '''
                        We break the here for avoid double counting overstay in one day period - Alif 
                        
                        Break if the hour is less than overstay hours.
                        'test_flat_range_process_count_amount_05_59_IN_00_00_01_OUT_next_day_motor' failed if we
                        break rightaway. -Rei

                        '''
                        if total_hours <= len(overstay_hours):
                            break

        elif left_hours <= 24:
            '''
            This part is added since when we test 'test_flat_range_process_count_amount_00_00_IN_00_00_01_OUT_2_days_motor', the test failed. The program returns 2 days of overstay but it should be 3. Consulted with Natasha. -Rei
            '''
            if left_hours == 0:
                if not bool(set(check_array) & set(overstay_hours)):
                    '''
                    Was breaking the program, saving it just in case
                    '''
                    # total_overstay_days = 0
                    pass
                else:
                    second_condition = int(result.strftime("%S")) != 0
                    third_condition = int(result.strftime("%M")) != 0
                    if second_condition or third_condition:

                        total_overstay_days += 1
                return total_overstay_days
            """
            We decrement the time using the time out so we could check the left hours passing the overstay period or not
            """
            for i in range(left_hours, -1, -1):
                """
                Since we already add 1 hour previously, so as example: 10:00 we added one hour to 11:00.
                We still got the 10:00 to be checked to our overstay period.
                """
                result = result - timedelta(hours=1)
                # Change it into hour and cast into integer
                hour = int(result.strftime("%H"))

                """If the integer hour is in our overstay hours, it gonna add the total overstay and break the loops"""
                if hour in overstay_hours:
                    total_overstay_days += 1
                    if not self.price_model.get_overstay_type():
                        """
                        If not progressive, we break right away since we don't need to know
                        for how long the PJP stays within the overstay range
                        """
                        break

            """ 
            Did ya still confused?        
            As example: 
            Range 23:00-04:00
            In: 2022-08-22 22:30:00
            Out: 2022-08-23 23:30:00
            
            It's counted as 2 overstay days, why?
            First we get total by 25 hours.
            
            The left hours is 1.
            We decrement the time by 1 hour.
            
            Since the out time is 2022-08-23 23:30:00 and plus by 1 is 2022-08-24 00:30:00
            When we decrement by 1, we got 23:00.
            23:00 -> 23.
            
            23 is in the array since 23:00-04:00 is [23, 0, 1, 2, 4]
            
            Voila, you won't be messed up.
            """

        return total_overstay_days

    def count_duration_days(self, total_hours: int):
        total_overstay_time = 0
        total_overstay_time = math.floor(
            total_hours / self.price_model.get_overstay_duration())

        if total_hours % self.price_model.get_overstay_duration() == 0:
            total_overstay_time = math.ceil(
                total_hours / self.price_model.get_overstay_duration())

        if self.price_model.get_overstay_type():
            '''
            with max(), we can set the default value. so if it returns negative, it will
            set it to 0. 

            if 0, it means that it is at least 1 hour of overstay. for example, ov duration is 6
            and the user stayed for 6 hours. Naturally, the user will be charged with ov. that's why 
            we have '=+ 1'
            '''
            total_overstay_time = max(
                total_hours - self.price_model.get_overstay_duration(), 0)
            total_overstay_time += 1

        return total_overstay_time

    def count_overstay_fee(self, total_overstay_time: int) -> int:
        price = 0
        amount = 0
        if self.price_model.get_overstay_price() > 0:
            price = self.price_model.get_overstay_price()

            if not total_overstay_time:
                amount = 0
            elif self.price_model.get_overstay_type() == OverstayCountType.PROGRESSIVE.value:
                amount = self.progressive(total_hours=total_overstay_time)
            elif self.price_model.get_overstay_type() == OverstayCountType.LIMITED_PROGRESSIVE.value:
                amount = self.limited_progressive(total_hours=total_overstay_time)
            else:
                amount = price * total_overstay_time

        return amount, price

    def progressive(self, total_hours: int):
        initial_time = self.price_model.get_overstay_progressive_time_start()
        next_hours = self.price_model.get_overstay_progressive_time_next()
        first_price = self.price_model.get_overstay_start_price()
        next_price = self.price_model.get_overstay_next_price()
        amount = first_price

        if total_hours > next_hours:
            left_hours = total_hours - initial_time
            if next_hours > 1:
                left_hours = int(left_hours / next_hours)

            amount = first_price + (next_price * left_hours)

        return amount

    def limited_progressive(self, total_hours: int):
        max_hours = self.price_model.get_overstay_max_hours()
        max_price = self.price_model.get_overstay_max_price()

        overstay_days = math.floor(total_hours/max_hours)
        left_hours = total_hours % max_hours
        amount = 0

        if overstay_days > 0 and max_price > 0:
            amount = self.price_model.get_overstay_max_price() * overstay_days
            if left_hours > 0:
                amount += self.count_amount_limited_progressive(hours=left_hours)

        elif overstay_days >= 0:
            amount = self.count_amount_limited_progressive(hours=total_hours)
            return amount

        return amount

    def count_amount_limited_progressive(self, hours) -> int:
        '''
        Count the amount based on the hours the user stays
        '''
        amount = self.price_model.get_overstay_start_price()
        hours -= self.price_model.get_overstay_progressive_time_start()

        if hours > 0 :
            hours = math.ceil(hours / self.price_model.get_overstay_progressive_time_next())
            amount += self.price_model.get_overstay_next_price() * hours

        if amount >= self.price_model.get_overstay_max_price() and self.price_model.get_overstay_max_price() > 0:
            amount = self.price_model.get_overstay_max_price()

        return amount

    def calculate_overstay_hours(self, overstay_hours: list, user_hours: list, total_hours: int):
        '''
        Handles how long the user stays within the overstay hours
        '''
        start, end = user_hours
        counted_hours = 0
        same_enter_and_exit = False

        if start == end:
            same_enter_and_exit = True

        # Normalize the end hour if it's less than the start hour (indicating a wrap-around midnight)
        if end <= start and total_hours > 0 :
            end += 24

        # Normalize the overstay hours to handle wrap-around at midnight
        normalized_overstay = [(hour if hour >= start else hour + 24) for hour in overstay_hours]

        for hour in normalized_overstay:
            if start <= hour <= end:
                counted_hours += 1

        # If its total hours is 24 then we should add one more hour since we the user entered and exit with the same number (not hour, different things!)
        if same_enter_and_exit and start in normalized_overstay and total_hours == 24:
            counted_hours += 1

        return counted_hours