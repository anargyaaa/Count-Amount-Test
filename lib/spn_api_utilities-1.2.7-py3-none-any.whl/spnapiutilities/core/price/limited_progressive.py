import math

from spnapiutilities.constants.price_constant import PriceType
from spnapiutilities.core.price.base_price import BasePrice
from spnapiutilities.core.price.price_model import PriceModel


class LimitedProgressive:
    def __init__(self, price_model: PriceModel):
        self.price_model: PriceModel = price_model
        self.total_hours: int = self.price_model.get_total_hours()

        self.amount: int = 0

    def execute(self):
        count_type = self.price_model.get_count_type()
        max_hours = 24 if self.price_model.get_max_hours(
        ) < 1 else self.price_model.get_max_hours()
        amount = 0
        if count_type == PriceType.COUNT_TYPE_RANGE.value:
            period = self.price_model.get_start_hours() + self.price_model.get_next_hours()
            days = int(self.total_hours / period)

            if days > 0:
                amount += (days * self.price_model.get_next_price())

            left_hours = self.total_hours % period
            amount += self.price_model.get_start_price()

            if left_hours > 0 and self.price_model.get_start_hours() < left_hours < period:
                amount += self.price_model.get_next_price()

            if self.price_model.get_max_price() > 0 and amount > self.price_model.get_max_price():
                amount = self.price_model.get_max_price()

        elif count_type == PriceType.COUNT_TYPE_INCREMENT.value:
            days = int(self.total_hours / max_hours)
            left_hours = int(self.total_hours % max_hours)
            within_a_day = False

            if days > 0 and self.price_model.get_max_price() > 0:
                '''
                If the transaction is in multiple days, then we
                multiply the max price with the days
                '''
                amount = self.price_model.get_max_price() * days
            elif days > 0 and self.price_model.get_max_price() == 0:
                left_hours = self.total_hours
                amount += self.process_count_limited_progressive(left_hours)
                left_hours = 0
            elif days == 0:
                '''
                If the transaction is less than a day, we calculate the
                total hours
                '''
                amount += self.process_count_limited_progressive(
                    self.total_hours)
                within_a_day = True

            if left_hours < 1:
                return amount

            if not within_a_day:
                '''
                If the transaction is more than one day, then we need to calculate
                the extra hours to be incremented to the amount. 

                For example, the duration is 25 hours, it is counted as
                2 days and 1 hour. The extra hour will be counted here
                '''
                amount += self.process_count_limited_progressive(left_hours)

        return amount

    def process_count_limited_progressive(self, left_hours: int):
        left_amount = 0
        left_amount += self.price_model.get_start_price()
        left_hours -= self.price_model.get_start_hours()

        if left_hours > 0:
            left_hours = math.ceil(
                left_hours / self.price_model.get_next_hours())
            left_amount += (self.price_model.get_next_price() * left_hours)

        if left_amount >= self.price_model.get_max_price() and self.price_model.get_max_price() > 0:
            left_amount = self.price_model.get_max_price()

        return left_amount

    # NOTE Ini perhitungan yang sudah lama di api utilities, untuk sekarang ku overwrite agar test cases pass semua -Rei

    # def execute(self):
    #     count_type = self.price_model.get_count_type()
    #     total_time = (
    #         self.price_model.get_start_hours() + self.price_model.get_next_hours()
    #     )

    #     if count_type == PriceType.COUNT_TYPE_RANGE.value:
    #         """
    #         We divide by maximum hour of pricing and round up the
    #         total hours to get how many days the vehicle was parked
    #         """
    #         days = math.ceil(self.total_hours / 24)
    #         total_hours = self.total_hours

    #         for i in range(days):
    #             calculate = self.calculate_left_hours(total_hours)
    #             left_hours = calculate["left_hours"]
    #             left = calculate["left"]

    #             between = self.price_model.get_start_hours() < left_hours <= total_time

    #             if left_hours > 0:
    #                 total_hours = left

    #             self.amount += self.price_model.get_start_price()

    #             if between:
    #                 self.amount += self.price_model.get_next_price()

    #     elif count_type == PriceType.COUNT_TYPE_INCREMENT.value:
    #         if self.price_model.get_max_hours() > 0:
    #             days = math.ceil(self.total_hours / 24)
    #             left_hours = self.total_hours

    #             for i in range(days):
    #                 left_hours = self.count_type_increment(left_hours)
    #         else:
    #             self.count_type_increment(self.total_hours)

    #     return self.amount

    # def count_type_increment(self, left_hours):
    #     amount = 0
    #     print(self.price_model.get_start_price())
    #     amount += self.price_model.get_start_price()

    #     left = 0
    #     """
    #         if price more than max hour we do some calculation
    #         for getting the left hours to be counted with total amount.
    #         Ex: Total hours = 25 hours
    #         total hours - 24 = 1
    #         so the left hours should 1 hour, and we calculate the hours before loop, which is 24.
    #         return 1 because that was the left hour.

    #         And for the next loop, the total hours is 1 to be counted.
    #     """
    #     if self.price_model.get_max_hours() > 0:
    #         calculate = self.calculate_left_hours(left_hours)
    #         left_hours = calculate["left_hours"]
    #         left = calculate["left"]

    #     if left_hours > self.price_model.get_start_hours():
    #         more_than_initial = left_hours - self.price_model.get_start_hours()

    #         stay_time = (
    #             self.price_model.get_next_hours()
    #             if self.price_model.get_next_hours() > 0
    #             else 1
    #         )
    #         count_hours = more_than_initial / stay_time
    #         count_hours = math.ceil(count_hours)

    #         amount += count_hours * self.price_model.get_next_price()

    #     check = amount > self.price_model.get_max_price()
    #     if check and self.price_model.get_max_price() > 0:
    #         amount -= amount
    #         amount += self.price_model.get_max_price()

    #     self.amount += amount
    #     return left

    # def calculate_left_hours(self, left_hours):
    #     total_hours = left_hours
    #     left_hours = total_hours - self.price_model.get_max_hours()
    #     left = left_hours

    #     """
    #         We check for the left hours should be greater than 0 means
    #         it should be minus between the total hours and left hours.

    #         Example, left hours = 25 (total_hours) - 1 (calculation between total hours - max hour pricing)
    #     """
    #     if left_hours > 0:
    #         left_hours = total_hours - left_hours
    #     else:
    #         left_hours = total_hours

    #     return {"left": left, "left_hours": left_hours}
