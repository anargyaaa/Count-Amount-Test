import math

from spnapiutilities.core.price.base_price import BasePrice
from spnapiutilities.core.price.price_model import PriceModel

class Flat:
    def __init__(self, price_model: PriceModel):
        self.__price_model = price_model
    
    def execute(self):
        amount = math.ceil(self.__price_model.get_total_hours() / 24) * self.__price_model.get_price()
        return amount