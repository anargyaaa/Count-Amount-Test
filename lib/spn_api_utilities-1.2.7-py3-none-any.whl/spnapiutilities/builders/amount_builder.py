""" 
WARNING: This class contains legacy code. Proceed with caution and consider refactoring. 
The code may be outdated, inefficient, or hard to maintain. Exercise care when making changes to avoid unintended consequences. 
"""

import math
from spnapiutilities.constants.price_constant import PriceType
from spnapiutilities.helpers.datetime_helper import DateTimeHelper
from spnapiutilities.helpers.datetime_diff_helper import DateTimeDifferenceHelper
from spnapiutilities.helpers.string_helper import StringHelper

class CountAmountBuilder:
    def __init__(self, time_in:int = 0):
        self.time_in = time_in # Waktu masuk (timemillis) 
        
        self.overnight_price = None # Tarif Inap
        self.max_price = None # Tarif Maksimal 
        self.next_price = None # Tarif Selanjutnya dari Tarif dasar, misal tarif dasar 3000, tarif selanjutnya per jam 1000
        self.price = None # Tarif dasar
        
        self.type = None # Tipe Perhitungan Lokasi
        self.count_type = None # Tipe Perhitungan Untuk Limited Progressive: Range / Increment

        self.initial_time = None # Waktu awal perhitungan
        self.stay_time = None # Waktu parkir
        
        self.grace_period = None # Waktu grace period (menit)
        self.discount = 0 # Diskon (Apabila ada)
        
        self.amount = 0 
        
        self.total_hours = None # Jumlah jam yang didapatkan
        self.max_hours = None # Jumlah maksimal jam dari tarif yang ada
        self.min_hours = None # Minimal Jam
        self.overnight_days = 0 # Jumlah menginap
        
        self.payload = {}
        
    def set_max_price(self, max_price):
        self.max_price = max_price   
    
    def set_next_price(self, next_price):
        self.next_price = next_price

    def set_price(self, price):
        self.price = price
    
    def set_type(self, spot_type):
        self.type = spot_type
        
    def set_count_type(self, count_type):
        self.count_type = count_type     
    
    def set_stay_time(self, stay_time):
        self.stay_time = stay_time
        
    def set_grace_period(self, grace_period):
        self.grace_period = grace_period

    def set_discount(self, discount):
        self.discount = discount      
    
    def set_overnight_price(self, overnight_price):
        self.overnight_price = overnight_price   
    
    def set_initial_time(self, initial_time):
        self.initial_time = initial_time   
    
    def set_max_hours(self, max_hours):
        self.max_hours = max_hours
        
    def set_min_hours(self, min_hours):
        self.min_hours = min_hours   
    
    def build(self):
        discount = 0
        time_out = DateTimeHelper.get_current_millisecond()
        
        count_hours = DateTimeDifferenceHelper.count_hours_with_data(int(self.time_in), time_out)
        self.total_hours = count_hours["round_up"]
        
        real_total_hours = self.total_hours

        if self.type == PriceType.FLAT.value:
            self.count_flat()
        elif self.type == PriceType.PROGRESSIVE.value:
            self.count_progressive()
        elif self.type == PriceType.LIMITED_PROGRESSIVE.value:
            self.count_limited_progressive()
        else:
            raise Exception("Tipe pembayaran tidak ditemukan!")

        grace_period = False
        if self.grace_period:
            grace_period = self.check_grace_time(time_out)

        parking_price = self.amount
        
        overnight_price = self.count_overnight_amount(real_total_hours)
        if overnight_price > 0:
            self.amount += overnight_price
        
        self.amount = self.amount - self.discount
        self.payload = {
            "amount": self.amount,
            "total_hours": real_total_hours,
            "total_amount": self.amount,
            "time_out": time_out,
            "discount": discount,
            "price": parking_price,
            "parking_price": parking_price,
            "overnight_price": overnight_price,
            "overnight_days": self.overnight_days,
            "grace_period": grace_period,
            "count_hours": count_hours
        }
        
        self.mapping_detail()
        
        return self.payload

    def mapping_detail(self):
        logs = []
        
        logs.append({
            "message": f"Biaya Parkir {self.payload['total_hours']} jam",
            "values": StringHelper.rupiah_format_currency(amount=float(self.payload['parking_price'])),
        })
        
        if self.payload['overnight_price'] and self.payload['overnight_price'] > 0:
            logs.append({
                "message": f"Biaya parkir inap {self.payload['overnight_days']} hari",
                "values": StringHelper.rupiah_format_currency(amount=float(self.payload['overnight_price'])),
            })  
            
        self.payload['logs'] = logs

    def count_overnight_days(self, total_hours):
        return math.floor(total_hours / 24.01)
        
    def count_overnight_amount(self, total_hours):
        if not self.overnight_price:
            return 0

        self.overnight_days = self.count_overnight_days(total_hours)
        
        overnight_price = 0

        if self.overnight_days > 0:
            overnight_price = self.overnight_price * self.overnight_days
            return overnight_price
        
        return overnight_price

    def check_grace_time(self, time_out):
        dif = DateTimeDifferenceHelper.get_different_timemillis_in_minutes(self.time_in, time_out)

        if dif < self.grace_period:
            return True
        
        return False

    def count_flat(self):
        self.amount = math.ceil(self.total_hours / 24) * self.price
        return self.amount

    def count_progressive(self):
        # Count the real value of hour
        if self.total_hours <= self.initial_time:
            self.amount = self.price
            return self.amount
        
        left_hours = self.total_hours - self.initial_time
        self.amount = self.price + (self.next_price * left_hours)
        return self.amount
            

    def count_limited_progressive(self):
    
        count_type = self.count_type
        total_time = self.initial_time + self.stay_time

        if count_type == PriceType.COUNT_TYPE_RANGE.value:
            """
                We divide by maximum hour of pricing and round up the
                total hours to get how many days the vehicle was parked
            """
            days = math.ceil(self.total_hours / 24)
            total_hours = self.total_hours

            for i in range(days):

                calculate = self.calculate_left_hours(total_hours)
                left_hours = calculate['left_hours']
                left = calculate['left']

                between = self.initial_time < left_hours <= total_time

                if left_hours > 0:
                    total_hours = left

                self.amount += self.price

                if between:
                    self.amount += (self.next_price)

        elif count_type == PriceType.COUNT_TYPE_INCREMENT.value:

            if self.max_hours > 0:
                days = math.ceil(self.total_hours / 24)
                left_hours = self.total_hours

                for i in range(days):
                    left_hours = self.count_type_increment(left_hours)
            else:
                self.count_type_increment(self.total_hours)

    def count_type_increment(self, left_hours):
        amount = 0
        amount += self.price

        left = 0
        """
            if price more than max hour we do some calculation
            for getting the left hours to be counted with total amount.
            Ex: Total hours = 25 hours
            total hours - 24 = 1
            so the left hours should 1 hour, and we calculate the hours before loop, which is 24.
            return 1 because that was the left hour.

            And for the next loop, the total hours is 1 to be counted.
        """
        if self.max_hours > 0:
            calculate = self.calculate_left_hours(left_hours)
            left_hours = calculate['left_hours']
            left = calculate['left']

        if left_hours > self.initial_time:
            more_than_initial = left_hours - self.initial_time

            stay_time = self.stay_time if self.stay_time > 0 else 1
            count_hours = more_than_initial / stay_time
            count_hours = math.ceil(count_hours)

            amount += (count_hours * self.next_price)

        check = amount > self.max_price
        if check and self.max_price > 0:
            amount -= amount
            amount += self.max_price
        # elif check and self.max_price == 0:
        #     amount = self.max_price

        self.amount += amount
        return left

    def calculate_left_hours(self, left_hours):
        total_hours = left_hours
        left_hours = total_hours - self.max_hours
        left = left_hours

        """
            We check for the left hours should be greater than 0 means
            it should be minus between the total hours and left hours.

            Example, left hours = 25 (total_hours) - 1 (calculation between total hours - max hour pricing)
        """
        if left_hours > 0:
            left_hours = total_hours - left_hours
        else:
            left_hours = total_hours

        return {"left": left, "left_hours": left_hours}
