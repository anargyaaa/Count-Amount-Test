from spnapiutilities.constants.price_constant import OverstayAffectedUsers, PriceType
from spnapiutilities.core.price.flat import Flat
from spnapiutilities.core.price.limited_progressive import LimitedProgressive
from spnapiutilities.core.price.overstay import Overstay
from spnapiutilities.core.price.period import Period
from spnapiutilities.core.price.price_model import PriceModel
from spnapiutilities.core.price.progressive import Progressive
from spnapiutilities.helpers.datetime_diff_helper import DateTimeDifferenceHelper
from spnapiutilities.helpers.string_helper import StringHelper


class ParkingAmountBuilder:
    def __init__(self, model: PriceModel):
        self.__price_model: PriceModel = model

        self.__amount = 0
        self.__overnight_days = 0
        self.__overstay_amount = 0

        self.__payload = {}

    def build(self):
        grace_period = self.check_grace_time(self.__price_model.get_time_out())

        factory = None
        if self.__price_model.get_price_type() == PriceType.FLAT.value:
            factory = Flat(self.__price_model)
        elif self.__price_model.get_price_type() == PriceType.LIMITED_PROGRESSIVE.value:
            factory = LimitedProgressive(self.__price_model)
        elif self.__price_model.get_price_type() == PriceType.PROGRESSIVE.value:
            factory = Progressive(self.__price_model)
        elif self.__price_model.get_price_type() == PriceType.PERIOD.value:
            factory = Period(self.__price_model)
        else:
            raise Exception("Wrong type counting!")

        if not grace_period:
            self.__amount = factory.execute()

        parking_amount = self.__amount

        is_affected_all = (
            self.__price_model.get_overstay_affected_user()
            == OverstayAffectedUsers.ALL.value
        )
        is_affected_membership_only = self.check_if_membership()
        is_affected_non_membership_only = (
            self.__price_model.get_overstay_affected_user()
            == OverstayAffectedUsers.NON_MEMBER.value
            and not self.__price_model.get_is_membership()
        )

        # NOTE Set default value of overstay data
        overstay_data = {"amount": 0, "price": 0, "total_days": 0}

        if (
            is_affected_all
            or is_affected_membership_only
            or is_affected_non_membership_only
        ):
            overstay_data = Overstay(self.__price_model).execute()
            if overstay_data.get("amount") > 0:
                self.__overstay_amount = overstay_data.get("amount")

        if self.__price_model.get_discount():
            self.__amount = self.__amount - self.__price_model.get_discount()

        if self.__price_model.get_point():
            self.__amount = self.__amount - self.__price_model.get_point()

        # NOTE To match with existing tests, we need to reset the parking price to 0
        # since it is member.
        if self.__price_model.get_is_membership():
            self.__amount = self.__amount - parking_amount
            parking_amount = 0

        self.__amount += self.__overstay_amount

        self.__payload = {
            "parking": {
                "price": self.__price_model.get_start_price(),
                "amount": parking_amount,
                "total_hours": self.__price_model.get_total_hours(),
                "total_hours_before_round_up": self.__price_model.get_total_hours_before_round_up(),
                "total_minutes": self.__price_model.get_total_minutes(),
                "is_grace_period": grace_period,
                "discount": self.__price_model.get_discount(),
                "point": self.__price_model.get_point(),
            },
            "overstay": {
                "price": self.__price_model.get_overstay_price(),
                "amount": self.__overstay_amount,
                "is_overstay": True if overstay_data.get("amount") > 0 else False,
                "total_days": overstay_data.get("total_days"),
            },
            "total": {"amount": self.__amount},
            "amount": self.__amount,
            "total_hours": self.__price_model.get_total_hours(),
            "total_amount": self.__amount,
            "time_out": self.__price_model.get_time_out(),
            "discount": self.__price_model.get_discount(),
            "price": self.__price_model.get_start_price(),
            "parking_price": self.__price_model.get_start_price(),
            "overnight_price": overstay_data.get("amount"),
            "overnight_days": overstay_data.get("total_days"),
            "grace_period": grace_period,
            "count_hours": self.__price_model.get_total_hours_before_round_up(),
        }

        self.mapping_detail()

        return self.__payload

    def mapping_detail(self):
        logs = []

        logs.append(
            {
                "message": f"Biaya Parkir {self.__payload['total_hours']} jam",
                "values": StringHelper.format_rupiah(
                    amount=float(self.__payload["parking_price"])
                ),
            }
        )

        if self.__payload["overnight_price"] and self.__payload["overnight_price"] > 0:
            logs.append(
                {
                    "message": f"Biaya parkir inap {self.__payload['overnight_days']} hari",
                    "values": StringHelper.format_rupiah(
                        amount=float(self.__payload["overnight_price"])
                    ),
                }
            )

        if self.__payload["discount"] and self.__payload["discount"] > 0:
            logs.append(
                {
                    "message": f"Biaya Potongan Harga",
                    "values": StringHelper.format_rupiah(
                        amount=float(self.__payload["discount"])
                    ),
                }
            )

        self.__payload["logs"] = logs

    def check_grace_time(self, time_out):
        if self.__price_model.get_grace_period() < 1:
            return False

        difference = DateTimeDifferenceHelper.get_different_timemillis_in_minutes(
            self.__price_model.get_time_in(), time_out
        )

        if (
            difference <= self.__price_model.get_grace_period()
            and not self.__price_model.get_membership_daily_transaction()
        ):
            return True

        return False

    def check_if_membership(self) -> bool:
        '''
        This check which membership product should be affected.
        '''
        is_membership = False
        member_affected_product_id = self.__price_model.get_overstay_product_member()
        current_member_id = self.__price_model.get_is_membership()
        is_member_affected = self.__price_model.get_overstay_affected_user() == OverstayAffectedUsers.MEMBER.value

        if not current_member_id or not is_member_affected:
            '''
            if not membership, the current member id should be empty.
            if the affected is not member then we skip this entirely
            '''
            return is_membership

        '''
        member_affected_product_id should be a list of member product id. If the list is empty 
        then we assume that everyone get a piece of the pie.
        '''
        if not member_affected_product_id:
            is_membership = True
            return is_membership

        '''
        get_is_membership got repurposed, it used to only contain bool but now it should contain
        the member product's id. So we check whether the id exists within the list
        '''
        if current_member_id and current_member_id in member_affected_product_id:
            is_membership = True

        return is_membership