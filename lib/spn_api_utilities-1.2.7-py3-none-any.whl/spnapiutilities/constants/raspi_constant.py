import enum


class printer_product_name(enum.Enum):
    PANDA = "PANDA-BLUETOOTH-THERMAL-123"
    EPSON = "EPSON-THERMAL-TMT82"

class printer_product_id(enum.Enum):
    PANDA = "P123"
    EPSON = "ETMT82"

class printer_vendor_id(enum.Enum):
    PANDA = "PANDA"
    EPSON = "EPSON"

class button_type(enum.Enum):
    DISPENSER = "DISPENSER"
    MANUAL = "MANUAL"

class rf_id_type(enum.Enum):
    MIFARE = "MIFARE"
    PROXIMITY = "PROXIMITY"

all_printer_id = [e.value for e in printer_product_id]
all_printer_vendors = [e.value for e in printer_vendor_id]
all_printer_name = [e.value for e in printer_product_name]


