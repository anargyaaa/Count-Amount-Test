import enum


class CardType(enum.Enum):
    COMPANY = "COMPANY"
    SPOT = "SPOT"

class CardLogType(enum.Enum):
    CREATE = "CREATE"
    SEND = "SEND"