import enum


class TicketStatus(enum.Enum):
    OPEN = "OPEN"
    CLOSED = "CLOSED"