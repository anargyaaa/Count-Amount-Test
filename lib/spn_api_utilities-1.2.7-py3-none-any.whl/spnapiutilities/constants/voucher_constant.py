import enum


class VoucherType(enum.Enum):
    DISCOUNT = "DISCOUNT"
    FULL_DISCOUNT = "FULL_DISCOUNT"
    SERVICE = "SERVICE"
    MEMBERSHIP = "MEMBERSHIP"
    REWARD = "REWARD"


voucher_types = [e.value for e in VoucherType]
non_members = [VoucherType.DISCOUNT.value, VoucherType.FULL_DISCOUNT.value, VoucherType.MEMBERSHIP.value]
