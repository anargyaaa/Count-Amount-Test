import enum


class AppType(enum.Enum):
    USER = "USER"
    MANAGEMENT = "MGMT"
    FINDER = "FINDER"

class AppPackage(enum.Enum):
    # SPN
    OFFICER_PROD = "id.spn.soulparkingofficer"
    OFFICER_DEV = "id.spn.soulparkingofficer.dev"
    USER_PROD = "id.spn.soulparkingfinder"
    USER_DEV = "id.spn.soulparkingfinder.dev"

    # Paralayang
    PARALAYANG_USER_PROD = "id.pamkotbandung.paralayang"
    PARALAYANG_USER_DEV = "id.pamkotbandung.paralayang.dev"
    PARALAYANG_OFFICER_PROD = "id.paralayang.soulparkingofficerparalayang"
    PARALAYANG_OFFICER_DEV = "id.paralayang.soulparkingofficerparalayang.dev"
    
all_app = [e.value for e in AppType]
all_package = [e.value for e in AppPackage]
