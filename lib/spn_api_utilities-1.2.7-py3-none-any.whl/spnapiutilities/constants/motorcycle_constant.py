import enum

class MotorcycleVerifiedStatus(enum.Enum):
    UNKNOWN = "0"
    VERIFIED = "1"
    UNVERIFIED = "2"
