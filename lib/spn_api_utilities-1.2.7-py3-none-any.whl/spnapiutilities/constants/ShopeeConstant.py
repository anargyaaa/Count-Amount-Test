import enum


class ShopeeTransactionType(enum.Enum):
    # refering to apendix 1A 
    PAYMENT_RECEIVED = 13
    REFUND_SEND = 15
    VOID = 26
    ADD = 32
    DEDUCT = 33
    CASH_IN = 36
    CASH_OUT = 37
    PAYMENT_AUTHORISED = 1000
    PAYMENT_CAPTURED = 1001


class PaymentStatusCode(enum.Enum):
    # refering to apendix 1B
    SUCCESS = 1
    NOT_FOUND = 2
    REFUND = 3
    VOID = 4
    PROCESSING = 5
    FAILED = 6
    

class PaymentStatusString(enum.Enum):
    # refering to apendix 1B
    SUCCESS = 'success'
    NOT_FOUND = 'not_found'
    REFUND = 'refund'
    VOID = 'void'
    PROCESSING = 'processing'
    FAILED = 'failed'

    RENEW = 'renew'


class Helper():
    def statusToString(status):
        if status == PaymentStatusCode.SUCCESS.value:
            status = PaymentStatusString.SUCCESS.value
        elif status == PaymentStatusCode.NOT_FOUND.value:
            status = PaymentStatusString.NOT_FOUND.value
        elif status == PaymentStatusCode.REFUND.value:
            status = PaymentStatusString.REFUND.value
        elif status == PaymentStatusCode.VOID.value:
            status = PaymentStatusString.VOID.value
        elif status == PaymentStatusCode.PROCESSING.value:
            status = PaymentStatusString.PROCESSING.value
        elif status == PaymentStatusCode.FAILED.value:
            status = PaymentStatusString.FAILED.value

        return status