import enum


class AdminitrativeType(enum.Enum):
    LOST_CARD = "LOST_CARD"
    DATA_CHANGE = "DATA_CHANGE"