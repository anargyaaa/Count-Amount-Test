import enum


class UserType(enum.Enum):
    USER = "U"
    MANAGEMENT = "M"
    OFFICER = "O" 
    RASPI = "R"