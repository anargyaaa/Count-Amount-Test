from enum import Enum

class ReconcileProvider(Enum):
    MKP = "MKP"
    STI = "STI"
    
class ReconcileStatus(Enum):
    QUEUE = "QUEUE"
    FAILED = "FAILED"
    FINISHED = "FINISHED"
    
all_providers = [e.value for e in ReconcileProvider]