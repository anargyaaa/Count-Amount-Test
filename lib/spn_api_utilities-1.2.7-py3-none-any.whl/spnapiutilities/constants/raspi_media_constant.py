import enum


class MediaStatus(enum.Enum):
    ACTIVE = "ACTIVE"
    DEFAULT = "DEFAULT"
    INACTIVE = "INACTIVE"


all_status = [e.value for e in MediaStatus]


class MediaVisibilityType(enum.Enum):
    DEFAULT = "DEFAULT"
    SCHEDULED = "SCHEDULED"


class MediaScheduleStatus(enum.Enum):
    SHOWING = "SHOWING"
    COMING_SOON = "COMING_SOON"
