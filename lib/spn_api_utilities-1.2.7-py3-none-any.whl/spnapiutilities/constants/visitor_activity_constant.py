import enum

class VisitorActivityEvent(enum.Enum):
    MEMBER_EXPIRED_IN = "MEMBER_EXPIRED_IN"
    MEMBER_EXPIRED_OUT = "MEMBER_EXPIRED_OUT"
    COMMON_OPEN = "COMMON_OPEN"
    COMMON_CLOSE = "COMMON_CLOSE"
    VISITOR_OUT = "VISITOR_OUT"
    VISITOR_IN = "VISITOR_IN"

class ActivityTransactionType(enum.Enum):
    ALL = "ALL"
    IN = "IN"
    OUT = "OUT"

class ActivityType(enum.Enum):
    MEMBER = "MEMBER"
    GUEST = "GUEST"
    MASTER = "MASTER"
    
all_activity_event = [e.value for e in VisitorActivityEvent]
