import enum


class OfficerRole(enum.Enum):
    KASIR = "G"
    GASKIR = "J"
    CUCI = "C"
    HOTELIER = "H"
    ONSTREET = "O"
    ADMIN_PC = "M"
    SUPERVISOR = "V"
    VALET = "A"


officer_role = [e.value for e in OfficerRole]

