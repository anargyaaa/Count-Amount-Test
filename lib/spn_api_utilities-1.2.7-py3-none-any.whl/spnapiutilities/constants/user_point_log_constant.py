import enum

class UserPointLogType(enum.Enum):
    DISCOUNT = "DISCOUNT"
    CASHBACK = "CASHBACK"
    REWARD = "REWARD"

    """
    cashback and reward add point
    discount use point
    """
