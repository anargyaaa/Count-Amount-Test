import enum


class RedeemStatus(enum.Enum):
    PENDING = "PENDING"
    REDEEMED = "REDEEMED"
    REJECTED = "REJECTED"

all_redeem_status = [e.value for e in RedeemStatus]
