import enum

class InquiryStatus(enum.Enum):
    TODO = "TODO"
    PENDING = "PENDING"
    FAILED = "FAILED"
    SUCCESS = "SUCCESS"
    NOT_FOUND = "NOT_FOUND"


class InquiryType(enum.Enum):
    MKP = "MKP"
    STI = "STI"

class STIStatus(enum.Enum):
    STATUS_00 = "00"
    STATUS_01 = "01"
    STATUS_02 = "02"
    STATUS_03 = "03"
    STATUS_04 = "04"
    STATUS_05 = "05"
    STATUS_07 = "07"
    STATUS_08 = "08"
    STATUS_09 = "09"
    STATUS_10 = "10"
    STATUS_11 = "11"

    MSG_00 = "Accepted"
    MSG_01 = "invalid Format"
    MSG_02 = "Duplicate Data"
    MSG_03 = "Transaction count not match with data transaction"
    MSG_04 = "Transaction amount not match with data transaction"
    MSG_05 = "Invalid Merchant Terminal"
    MSG_07 = "Data Corrupt"
    MSG_08 = "Invalid Device SN"
    MSG_09 = "Invalid Bank Log"
    MSG_10 = "Invalid Filename Format"
    MSG_11 = "Invalid Header Format"

inquiry_types = [e.value for e in InquiryType]
inquiry_status = [e.value for e in InquiryStatus]