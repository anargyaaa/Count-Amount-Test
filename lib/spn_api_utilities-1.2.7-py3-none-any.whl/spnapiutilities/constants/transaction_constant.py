import enum


class TransactionStatus(enum.Enum):
    PAID = "PAID"

    DATANG = "D"
    PENEMPATAN = "P"
    PERMINTAAN_AMBIL = "M"
    PENGAMBILAN = "A"
    KELUAR = "K"
    BERMASALAH = "X"
    OTHER = "O"
    PENGANTARAN = "W"

    ORDERED = "ORDERED"
    CANCELED = "CANCELED"
    FINISHED = "FINISHED"
    EXPIRED = "EXPIRED"
    FAILED = "FAILED"

    DELETED = "DELETED"
    ONGOING = "ONGOING"
    PENDING = "PENDING"
    REJECTED = "REJECTED"


class TransactionLogStatus(enum.Enum):
    MASUK = "D"  # from M -> D
    CHECKOUT = "M"  # from C -> M
    PAYMENT_METHOD = "P"
    UBAH_PAYMENT_METHOD = "U"
    BAYAR = "A"  # from B -> A
    TRANSAKSI_SELESAI = "K"  # from S to K
    TRANSAKSI_FINDER_BERMASALAH = "X"
    TUTUP_PAKSA = "F"
    UBAH_PLAT = "I"
    CLAIM_TIKET = "C"
    SEND = "S"
    PAY_AT_ENTRY = "LB"
    
    USER_LOCK_PAYMENT = "USER_LOCK_PAYMENT"
    OFFICER_LOCK_PAYMENT = "OFFICER_LOCK_PAYMENT"

    MASUK_BASEMENT = "MASUK_BASEMENT"
    MEMBER_IN = "MEMBER_IN"
    MEMBER_FINISH = "MEMBER_FINISH"

    DIHAPUS = "DELETED"
    FLAG_PROBLEM = "FLAG_PROBLEM"
    OVERNIGHT = "OVERNIGHT"
    LOST_TICKET = "LOST_TICKET"
    GENERATE_INQUIRY = "GENERATE_INQUIRY"

    # MEMESAN LAYANAN
    ORDERED_SERVICE = "ORDERED_SERVICE"
    ONGOING_SERVICE = "ONGOING_SERVICE"
    PAID_SERVICE = "PAID_SERVICE"
    FINISHED_SERVICE = "FINISHED_SERVICE"
    REJECTED_SERVICE = "REJECTED_SERVICE"
    POINT_USAGE = "POINT_USAGE"
    CHANGE_PAYMENT_METHOD = "CHANGE_PAYMENT_METHOD"

    ORDERED_MEMBERSHIP = "ORDERED_MEMBERSHIP"
    ONGOING_MEMBERSHIP = "ONGOING_MEMBERSHIP"
    PAID_MEMBERSHIP = "PAID_MEMBERSHIP"

    MIDTRANS_RENEW = "MIDTRANS_RENEW"
    MIDTRANS_NEW_ID = "MIDTRANS_NEW_ID"
    MIDTRANS_STATUS = "MIDTRANS_STATUS"
    MIDTRANS_CANCEL = "MIDTRANS_CANCEL"

    SHOPEE_RENEW = "SHOPEE_RENEW"
    SHOPEE_NEW_ID = "SHOPEE_NEW_ID"
    SHOPEE_STATUS = "SHOPEE_STATUS"
    SHOPEE_CRON_CHECK = "SHOPEE_CRON_CHECK"

    LINKAJA_RENEW = "LINKAJA_RENEW"
    LINKAJA_NEW_ID = "LINKAJA_NEW_ID"
    LINKAJA_STATUS = "LINKAJA_STATUS"

    MANLESS_TRANSACTION_IN = "MANLESS_TRANSACTION_IN"
    ONSTREET_TRANSACTION_IN = "ONSTREET_TRANSACTION_IN"
    OFFLINE_TRANSACTION_LOG = "OFFLINE_TRANSACTION_LOG"

    CREATED_BY_GASKIR = "CREATED_BY_GASKIR"  # from M -> D
    CLAIM_POINT_FROM_TICKET = "CLAIM_POINT_FROM_TICKET"

    ## valet
    VALET_REQUEST = "VALET_REQUEST"
    VALET_ACCEPT = "VALET_ACCEPT"
    VALET_REJECT = "VALET_REJECT"
    VALET_MASUK = "VALET_MASUK"
    VALET_KELUAR = "VALET_KELUAR"
    VALET_PENGANTARAN = "VALET_PENGANTARAN"



class TransactionRefType(enum.Enum):
    # REF TYPE
    REF_FINDER = "FINDER"
    OVERSTAY = "OVERSTAY"
    REF_SERVICE = "SERVICE"
    REF_DISCOUNT = "DISCOUNT"
    REF_MEMBERSHIP = "MEMBERSHIP"
    REF_LOST_TICKET = "LOST_TICKET"
    REF_VALET = "VALET"


class GuestMarkOut(enum.Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"


all_visitor_status = [e.value for e in GuestMarkOut]


class TransactionPaymentMethod(enum.Enum):
    PAYMENT_METHOD_MEMBERSHIP = "MEMBERSHIP"
    PAYMENT_METHOD_GRACE_PERIOD = "GRACE_PERIOD"
    PAYMENT_METHOD_CARD = "CARD"
    PAYMENT_METHOD_CASH = "CASH"
    PAYMENT_METHOD_PAY_AT_EXIT = "Bayar di Pintu Keluar"
    PAYMENT_VOUCHER_FULL_ONCE = "GRATIS SEKALI PARKIR"
    PAYMENT_METHOD_GOPAY = "GOPAY"
    PAYMENT_METHOD_SHOPEE = "SHOPEE"
    PAYMENT_METHOD_LINKAJA = "LINKAJA"
    # PAYMENT_METHOD_DANA = "DANA"
    PAYMENT_METHOD_OFFLINE_GOPAY = "OFF_GOPAY"
    PAYMENT_METHOD_OFFLINE_LINKAJA = "OFF_LINKAJA"
    PAYMENT_METHOD_OFFLINE_SHOPEE = "OFF_SHOPEE"
    PAYMENT_METHOD_OFFLINE_DANA = "OFF_DANA"
    PAYMENT_METHOD_OFFLINE_OVO = "OFF_OVO"
    PAYMENT_METHOD_OFFLINE_EMONEY_MANDIRI = "PAYMENT_EMONEY"
    PAYMENT_METHOD_OFFLINE_EMONEY_BCA = "PAYMENT_FLAZZ"
    PAYMENT_METHOD_OFFLINE_EMONEY_BNI = "PAYMENT_TAPCASH"
    PAYMENT_METHOD_OFFLINE_EMONEY_BRI = "PAYMENT_BRIZZI"
    PAYMENT_METHOD_OFFLINE_SPIN = "OFF_SPINPAY"
    PAYMENT_METHOD_BANK_TRANSFER = "BANK_TRANSFER"

    PAYMENT_METHOD_VA_BCA = "VA_BCA"
    PAYMENT_METHOD_VA_BNI = "VA_BNI"
    PAYMENT_METHOD_VA_MANDIRI = "VA_MANDIRI"
    PAYMENT_METHOD_VA_PERMATA = "VA_PERMATA"


class TransactionProblemReasonsConstant(enum.Enum):
    Sistem_Bermasalah = "SB"
    Tiket_Ganda = "TG"
    Member = "M"
    ORMAS = "O"
    APARAT = "PT"  # polisi tentara
    DIREKSI = "DB"
    Perawatan_Lokasi = "PL"


all_problem_transaction_reason = [
    e.value for e in TransactionProblemReasonsConstant]


class TransactionTypeConstant(enum.Enum):
    MEMBER = "MEMBER"
    NON_MEMBER = "NON_MEMBER"


class TransactionManlessPaymentMethod(enum.Enum):
    PAYMENT_METHOD_CASH = "CASH"
    PAYMENT_QRIS = "QRIS"
    PAYMENT_EMONEY_LUMINOUS = "EMONEY_LUMINOUS"
    PAYMENT_EMONEY_BCA = "EMONEY_BCA"
    PAYMENT_EMONEY_MANDIRI = "EMONEY_MANDIRI"
    PAYMENT_EMONEY_BRI = "EMONEY_BRI"
    PAYMENT_EMONEY_BNI = "EMONEY_BNI"
    PAYMENT_METHOD_GRACE_PERIOD = "GRACE_PERIOD"


all_manless_payment = [e.value for e in TransactionManlessPaymentMethod]

all_payment = [e.value for e in TransactionPaymentMethod]

offline_payment = [
    TransactionPaymentMethod.PAYMENT_METHOD_PAY_AT_EXIT.value,
    TransactionPaymentMethod.PAYMENT_METHOD_CASH.value,
    TransactionPaymentMethod.PAYMENT_METHOD_OFFLINE_SPIN.value,
    TransactionPaymentMethod.PAYMENT_METHOD_OFFLINE_DANA.value,
    TransactionPaymentMethod.PAYMENT_METHOD_OFFLINE_GOPAY.value,
    TransactionPaymentMethod.PAYMENT_METHOD_OFFLINE_LINKAJA.value,
    TransactionPaymentMethod.PAYMENT_METHOD_OFFLINE_SHOPEE.value,
    TransactionPaymentMethod.PAYMENT_METHOD_OFFLINE_OVO.value,
    TransactionPaymentMethod.PAYMENT_METHOD_OFFLINE_EMONEY_MANDIRI.value,
    TransactionPaymentMethod.PAYMENT_METHOD_OFFLINE_EMONEY_BCA.value,
    TransactionPaymentMethod.PAYMENT_METHOD_OFFLINE_EMONEY_BNI.value,
    TransactionPaymentMethod.PAYMENT_METHOD_GRACE_PERIOD.value,
]

online_payment = [
    TransactionPaymentMethod.PAYMENT_METHOD_SHOPEE.value,
    TransactionPaymentMethod.PAYMENT_METHOD_GOPAY.value,
    TransactionPaymentMethod.PAYMENT_METHOD_LINKAJA.value
]

midtrans_payment = [
    TransactionPaymentMethod.PAYMENT_METHOD_GOPAY.value,
    TransactionPaymentMethod.PAYMENT_METHOD_VA_BCA.value,
    TransactionPaymentMethod.PAYMENT_METHOD_VA_BNI.value,
    TransactionPaymentMethod.PAYMENT_METHOD_VA_MANDIRI.value,
    TransactionPaymentMethod.PAYMENT_METHOD_VA_PERMATA.value,
]

qris_statis = [
    TransactionPaymentMethod.PAYMENT_METHOD_OFFLINE_SPIN.value,
    TransactionPaymentMethod.PAYMENT_METHOD_OFFLINE_DANA.value,
    TransactionPaymentMethod.PAYMENT_METHOD_OFFLINE_GOPAY.value,
    TransactionPaymentMethod.PAYMENT_METHOD_OFFLINE_LINKAJA.value,
    TransactionPaymentMethod.PAYMENT_METHOD_OFFLINE_SHOPEE.value,
    TransactionPaymentMethod.PAYMENT_METHOD_OFFLINE_OVO.value,
]

emoney = [
    TransactionManlessPaymentMethod.PAYMENT_EMONEY_BCA.value,
    TransactionManlessPaymentMethod.PAYMENT_EMONEY_BNI.value,
    TransactionManlessPaymentMethod.PAYMENT_EMONEY_LUMINOUS.value,
    TransactionManlessPaymentMethod.PAYMENT_EMONEY_BRI.value,
    TransactionManlessPaymentMethod.PAYMENT_EMONEY_MANDIRI.value,
]

cashless = [
    TransactionPaymentMethod.PAYMENT_METHOD_GOPAY.value,
    TransactionPaymentMethod.PAYMENT_METHOD_SHOPEE.value,
    TransactionPaymentMethod.PAYMENT_METHOD_LINKAJA.value,
    TransactionPaymentMethod.PAYMENT_METHOD_OFFLINE_SPIN.value,
    TransactionPaymentMethod.PAYMENT_METHOD_OFFLINE_DANA.value,
    TransactionPaymentMethod.PAYMENT_METHOD_OFFLINE_GOPAY.value,
    TransactionPaymentMethod.PAYMENT_METHOD_OFFLINE_LINKAJA.value,
    TransactionPaymentMethod.PAYMENT_METHOD_OFFLINE_SHOPEE.value,
    TransactionPaymentMethod.PAYMENT_METHOD_OFFLINE_OVO.value,
    TransactionManlessPaymentMethod.PAYMENT_EMONEY_BCA.value,
    TransactionManlessPaymentMethod.PAYMENT_EMONEY_BNI.value,
    TransactionManlessPaymentMethod.PAYMENT_EMONEY_LUMINOUS.value,
    TransactionManlessPaymentMethod.PAYMENT_EMONEY_BRI.value,
    TransactionManlessPaymentMethod.PAYMENT_EMONEY_MANDIRI.value,
    TransactionManlessPaymentMethod.PAYMENT_QRIS.value,
]
