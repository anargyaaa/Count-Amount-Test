import enum


class MobileAppPackage(enum.Enum):
    GASKIR_APP_PROD = "id.spn.soulparkingofficer"
    GASKIR_APP_DEV = "id.spn.soulparkingofficer.dev"
    USER_APP_PROD = "id.spn.soulparkingfinder"
    USER_APP_DEV = "id.spn.soulparkingfinder.dev"

    PARALAYANG_GASKIR_APP = ""
    PARALAYANG_USER_APP = ""


package_list = [e.value for e in MobileAppPackage]
