import enum
import enum


class PriceType(enum.Enum):
    GENERAL = "GENERAL"
    FLAT = "FLAT"
    PROGRESSIVE = "PROGRESSIVE"
    PERIOD = "PERIOD"
    LIMITED_PROGRESSIVE = "LIMITED_PROGRESSIVE"

    BIG_MOTORCYCLE = "BIG_MOTORCYCLE"
    SMALL_MOTORCYCLE = "SMALL_MOTORCYCLE"

    COUNT_TYPE_FIRST_RATE = "FIRST_RATE"
    COUNT_TYPE_RANGE = "RANGE"
    COUNT_TYPE_INCREMENT = "INCREMENT"


class OverstayCountType(enum.Enum):
    PROGRESSIVE = "PROGRESSIVE"
    LIMITED_PROGRESSIVE = "LIMITED_PROGRESSIVE"


class FineType(enum.Enum):
    FINE_ONLY = "FINE_ONLY"
    PRICE_FINE = "PRICE_FINE"


class OverstayAffectedUsers(enum.Enum):
    ALL = 'ALL'
    MEMBER = 'MEMBER'
    NON_MEMBER = 'NON_MEMBER'


class OverstayPriceTypes(enum.Enum):
    OVERSTAY_ONLY = "OVERSTAY_ONLY"
    PRICE_OVERSTAY = "PRICE_OVERSTAY"


class OverstayParameter(enum.Enum):
    DURATION = "DURATION"
    CURFEW = "TIME"


class VehicleTypes(enum.Enum):
    MT1 = "MT1"
    MT2 = "MT2"
    MT3 = "MT3"
    MT4 = "MT4"
    MT5 = "MT5"

    MB1 = "MB1"
    MB2 = "MB2"
    MB3 = "MB3"
    MB4 = "MB4"
    MB5 = "MB5"

    KL1 = "KL1"
    KL2 = "KL2"
    KL3 = "KL3"
    KL4 = "KL4"
    KL5 = "KL5"

    MT = "MT"
    MB = "MB"

    SMALL_MOTORCYCLE = "1"
    BIG_MOTORCYCLE = "2"


class AdminChargesMemberTypes(enum.Enum):
    CARD = "CARD"
    LICENSE_PLATE = "LICENSE_PLATE"


class AdministrativeChargesTypes(enum.Enum):
    DELETE_MEMBERSHIP_HISTORY = "DELETE_MEMBERSHIP_HISTORY"
    DELETE_MEMBERSHIP = "DELETE_MEMBERSHIP"
    IDENTITY_CHANGE = "IDENTITY_CHANGE"
    CHANGE_PERIOD = "CHANGE_PERIOD"


get_motorcycle_type = [PriceType.BIG_MOTORCYCLE.value,
                       PriceType.SMALL_MOTORCYCLE.value]

get_price_type = [PriceType.FLAT.value,
                  PriceType.PROGRESSIVE.value,
                  PriceType.LIMITED_PROGRESSIVE.value,
                  PriceType.PERIOD.value
                  ]

period_range = [0,1,2,3,4,5,6,7,8,9,10,
                11,12,13,14,15,16,17,18,19,20,
                21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36]

get_count_type = [PriceType.COUNT_TYPE_FIRST_RATE.value,
                  PriceType.COUNT_TYPE_RANGE.value,
                  PriceType.COUNT_TYPE_INCREMENT.value]

get_fine_type = [FineType.FINE_ONLY.value,
                 FineType.PRICE_FINE.value]

get_vehicle_code = [e.value for e in VehicleTypes]

member_types = [e.value for e in AdminChargesMemberTypes]
