import enum


class DiscountType(enum.Enum):
    VOUCHER = "VOUCHER"
    POINT = "POINT"
    DISCOUNT = "DISCOUNT"


discount_type = [e.value for e in DiscountType]
