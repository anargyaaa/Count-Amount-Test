import enum


class MembershipType(enum.Enum):
    TYPE_COMMON = "M"
    TYPE_DAILY = "day"
    TYPE_COMPANY_EMPLOYEE = "COMPANY_EMPLOYEE"

class MembershipExtension(enum.Enum):
    EXTENDED = "EXTENDED"
    NEW = "NEW"

class ProductMembershipMonthStartType(enum.Enum):
    FIRST_DAY_OF_MONTH = "FIRST_DAY_OF_MONTH"
    MIDDLE_DAY_OF_MONTH = "MIDDLE_DAY_OF_MONTH"
    DIRECT_ACTIVATION = "DIRECT_ACTIVATION"
    LAST_DAY_OF_MONTH = "LAST_DAY_OF_MONTH"
    
class MembershipLogStatus(enum.Enum):
    CREATED_BY_MGMT = "CREATED_BY_MGMT"
    CREATED_BY_USER = "CREATED_BY_USER"
    UPDATED = "UPDATED"
    DELETED = "DELETED"
    DELETED_BY_UPDATE = "DELETED_BY_UPDATE"
    PRINTED = "PRINTED"

class GuestType(enum.Enum):
    MASTER = "MASTER"
    GUEST = "GUEST"
    MEMBER = "MEMBER"
    
guest_types = [item.value for item in GuestType]


product_membership_list = [item.value for item in ProductMembershipMonthStartType]
