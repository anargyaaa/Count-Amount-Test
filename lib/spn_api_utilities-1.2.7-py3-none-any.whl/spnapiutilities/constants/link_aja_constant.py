import enum


class PaymentStatusCode(enum.Enum):
    SUCCESS = "00"
    PARAMETER_MISSING = "01"
    INVALID_TRANSACTION = "02"
    UNAUTHORIZED = "03"
    FAILED_TRANSACTION = "05"
    ITEM_LENGTH_EXCEEDED = "12"
    TRANSACTION_DOES_NOT_EXIST = "06"
    TRANSACTION_DOES_NOT_MATCH = "07"


class InquiryStatusCode(enum.Enum):
    SUCCESS = "00"
    FAILED = "90"
    FULL_REFUND = "91"
    PART_REFUND = "92"
    TIME_OUT = "68"


class PaymentStatusString(enum.Enum):
    SUCCESS = "success"
    PARAMETER_MISSING = "parameter missing"
    INVALID_TRANSACTION = "invalid transaction"
    UNAUTHORIZED = "unauthorized"
    FAILED_TRANSACTION = "failed transaction"
    ITEM_LENGTH_EXCEEDED = "items length exceeded"
    TRANSACTION_DOES_NOT_EXIST = "trx does not exist"
    TRANSACTION_DOES_NOT_MATCH = "trx does not match"

    RENEW = 'renew'


class Helper():
    def statusToString(status):
        if status == PaymentStatusCode.SUCCESS.value:
            return PaymentStatusString.SUCCESS.value
        if status == PaymentStatusCode.PARAMETER_MISSING.value:
            return PaymentStatusString.PARAMETER_MISSING.value
        if status == PaymentStatusCode.INVALID_TRANSACTION.value:
            return PaymentStatusString.INVALID_TRANSACTION.value
        if status == PaymentStatusCode.UNAUTHORIZED.value:
            return PaymentStatusString.UNAUTHORIZED.value
        if status == PaymentStatusCode.FAILED_TRANSACTION.value:
            return PaymentStatusString.FAILED_TRANSACTION.value
        if status == PaymentStatusCode.ITEM_LENGTH_EXCEEDED.value:
            return PaymentStatusString.ITEM_LENGTH_EXCEEDED.value
        if status == PaymentStatusCode.TRANSACTION_DOES_NOT_EXIST.value:
            return PaymentStatusString.TRANSACTION_DOES_NOT_EXIST.value
        if status == PaymentStatusCode.TRANSACTION_DOES_NOT_MATCH.value:
            return PaymentStatusString.TRANSACTION_DOES_NOT_MATCH.value

        return status
