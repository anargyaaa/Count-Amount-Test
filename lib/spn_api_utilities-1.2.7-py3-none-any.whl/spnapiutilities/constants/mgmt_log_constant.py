import enum

class ManagementLogType(enum.Enum):
    SPOT_CREATED = "SPOT_CREATED"
    SPOT_UPDATED = "SPOT_UPDATED"
    SPOT_DELETED = "SPOT_DELETED"
    PRODUCT_CREATED = "PRODUCT_CREATED"
    PRODUCT_UPDATED = "PRODUCT_UPDATED"
    PRODUCT_DELETED = "PRODUCT_DELETED"
    PRICE_CREATED = "PRICE_CREATED"
    PRICE_UPDATED = "PRICE_UPDATED"
    OFFICER_CREATED = "OFFICER_CREATED"
    OFFICER_DELETED = "OFFICER_DELETED"

class ManagementTable(enum.Enum):
    SPOT = "spot"
    PRODUCT = "product"
    PRICE = "price"
    OFFICER = "officer"


spot_log_type = [
    ManagementLogType.SPOT_CREATED.value,
    ManagementLogType.SPOT_UPDATED.value,
    ManagementLogType.SPOT_DELETED.value,
    ]

product_log_type = [
    ManagementLogType.PRODUCT_CREATED.value,
    ManagementLogType.PRODUCT_UPDATED.value,
    ManagementLogType.PRODUCT_DELETED.value,
    ]

price_log_type = [
    ManagementLogType.PRICE_CREATED.value,
    ManagementLogType.PRICE_UPDATED.value,
    ]
