import enum

class OTPType(enum.Enum):
    PHONENUMBER = "P"
    EMAIL = "E"
