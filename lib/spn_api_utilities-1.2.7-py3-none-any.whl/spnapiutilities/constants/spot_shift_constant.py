import enum


class SpotShiftTime(enum.Enum):
    yesterday = [-12,-11,-10,-9,-8,-7,-6,-5,-4,-3,-2,-1]
    today =     [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23]
    tomorrow =  [24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48]

class SpotShiftObject(enum.Enum):
    shift_start={
        "-12" : {
            "time":"12",
            "day":"yesterday"
        },
        "-11" : {
            "time":"12",
            "day":"yesterday"
        },
        "-10" : {
            "time":"12",
            "day":"yesterday"
        },
        "-9" : {
            "time":"12",
            "day":"yesterday"
        },
        "-8" : {
            "time":"12",
            "day":"yesterday"
        },
        "-7" : {
            "time":"12",
            "day":"yesterday"
        },
        "-6" : {
            "time":"12",
            "day":"yesterday"
        },
        "-5" : {
            "time":"12",
            "day":"yesterday"
        },
        "-4" : {
            "time":"12",
            "day":"yesterday"
        },
        "-3" : {
            "time":"12",
            "day":"yesterday"
        },
        "-2" : {
            "time":"12",
            "day":"yesterday"
        },
        "-1" : {
            "time":"12",
            "day":"yesterday"
        },
        "0" : {
            "time":"12",
            "day":"today"
        },
        "-12" : {
            "time":"12",
            "day":"yesterday"
        },
        "-12" : {
            "time":"12",
            "day":"yesterday"
        },
        "-12" : {
            "time":"12",
            "day":"yesterday"
        },
        "-12" : {
            "time":"12",
            "day":"yesterday"
        },
        "-12" : {
            "time":"12",
            "day":"yesterday"
        },
        "-12" : {
            "time":"12",
            "day":"yesterday"
        },
        "-12" : {
            "time":"12",
            "day":"yesterday"
        },
        "-12" : {
            "time":"12",
            "day":"yesterday"
        },
        "-12" : {
            "time":"12",
            "day":"yesterday"
        },
        "-12" : {
            "time":"12",
            "day":"yesterday"
        },
        "-12" : {
            "time":"12",
            "day":"yesterday"
        },
        "-12" : {
            "time":"12",
            "day":"yesterday"
        },
        "-12" : {
            "time":"12",
            "day":"yesterday"
        },
        "-12" : {
            "time":"12",
            "day":"yesterday"
        },
        "-12" : {
            "time":"12",
            "day":"yesterday"
        },
        "-12" : {
            "time":"12",
            "day":"yesterday"
        },
        "-12" : {
            "time":"12",
            "day":"yesterday"
        },
        "-12" : {
            "time":"12",
            "day":"yesterday"
        },
        "-12" : {
            "time":"12",
            "day":"yesterday"
        },
        "-12" : {
            "time":"12",
            "day":"yesterday"
        },
        "-12" : {
            "time":"12",
            "day":"yesterday"
        },
        "-12" : {
            "time":"12",
            "day":"yesterday"
        },
    }


