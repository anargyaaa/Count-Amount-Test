import enum


class MidtransStatus(enum.Enum):
    CAPTURE = "capture"
    CHALLENGE = "challenge"
    ACCEPT = "accept"
    CANCEL = "cancel"
    PENDING = "pending"
    DENY = "deny"
    EXPIRE = "expire"
    SETTLEMENT = "settlement"
    SUCCESS = "success"
    FAILURE = "failure"

    RENEW = "renew"
