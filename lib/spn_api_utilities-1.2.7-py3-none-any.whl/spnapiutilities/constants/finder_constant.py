import enum


class FinderType(enum.Enum):
    TYPE_ALL = "all"
    TYPE_IN = "in"
    TYPE_ONGOING = "ongoing"
    TYPE_OUT = "out"


class FinderStatus(enum.Enum):
    PARKING = "P"
    MOBILIZATION = "M"
    MOVING = "V"
    DONE = "D"

    # DEPRECATED - NOT USED ANYMORE
    TAKE = "T"
    OUT = "O"



class FinderMotorcycleSize(enum.Enum):
    SMALL = "1"
    BIG = "2"
