import enum


class ServiceType(enum.Enum):
    MOTORCYCLE_WASH = "MOTORCYCLE_WASH"
    HELM_WASH = "HELM_WASH"


service_list = [e.value for e in ServiceType]
