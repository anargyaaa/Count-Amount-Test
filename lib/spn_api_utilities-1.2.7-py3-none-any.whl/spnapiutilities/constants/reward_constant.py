import enum


class RewardType(enum.Enum):
    POINTS = "POINTS"
    PARKING_VOUCHER = "PARKING_VOUCHER"
