import enum
class SpotType(enum.Enum):
    CONVENTIONAL = 'CONVENTIONAL'
    COMPACT = 'COMPACT'
    MANLESS = 'MANLESS'
    ONSTREET = 'ONSTREET'
    CLUSTER = 'CLUSTER'

class RestrictiveShift(enum.Enum):
    RESTRICTIVE = 'RESTRICTIVE'
    LENIENT = 'LENIENT'

class PosGateType(enum.Enum):
    CHECK_OUT = 'checkout'
    CHECK_IN = 'checkin'

class TimezoneType(enum.Enum):
    WIB = 'Asia/Jakarta'
    WITA = 'Asia/Ujung_Pandang'
    WIT = 'Asia/Jayapura'

default_config = ["nama", "nomor", "email"]