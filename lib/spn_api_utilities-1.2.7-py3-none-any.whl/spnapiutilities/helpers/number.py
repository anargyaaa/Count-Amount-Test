from typing import Union
def toUint(num: int) -> Union[int, None]:
    """
    Make sure is unsign integer
    """
    if num is None:
        return None
    if num < 0:
        raise Exception("Must be unsign integer")
    return num
