from calendar import monthrange
from datetime import date, datetime, timedelta, timezone
import math
from spnapiutilities.helpers.datetime_helper import DateTimeHelper


class DateTimeDifferenceHelper:
    """
        Date Helper
    """
    
    @classmethod
    def get_start_and_end_from_month(cls, month, year):
        format = "%Y-%m-%d"
        _, num_days = monthrange(year, month)
        
        first_day = date(year, month, 1).strftime(format)
        last_day = date(year, month, num_days).strftime(format)
        return {"start": first_day, "end": last_day}
    
    
    @classmethod
    def get_milliseconds_from_date_time(cls, date_time, format='%Y-%m-%d %H:%M:%S'):    
        if type(date_time) == str:
            date_time = datetime.strptime(date_time, format)

        ts = date_time.timestamp()

        return int(round(ts * 1000))
    
    @classmethod
    def get_date_from_time_milliseconds(cls, ms):
        return datetime.fromtimestamp(int(ms) / 1000.0)
    
    @classmethod
    def get_string_from_datetime(cls, date_time, format="%Y-%m-%d %H:%M:%S"):
        return str(date_time.strftime(format))
    
    @classmethod
    def reformat_date_time(cls, date_time: str, format='%Y-%m-%d %H:%M:%S', new_format='%Y-%m-%d %H:%M:%S'): 
        date_time = datetime.strptime(date_time, format)
        return date.strftime(date_time, new_format)
    
    """
        Get Different Time
    """
    @classmethod 
    def get_different_timemillis_in_minutes(cls, start, end):
        difference = end - start
        difference = math.ceil(difference / 1000 / 60)
        return difference

    @classmethod
    def get_different_timemillis_in_hours(cls, start, end):
        difference = end - start
        difference = math.ceil(difference / 1000 / 60 / 60)
        return difference
    
    @classmethod
    def get_different_timemillis_in_hours_without_ceil(cls, start, end):
        difference = end - start
        difference = difference / 1000 / 60 / 60
        return difference

    @classmethod
    def get_different_timemillis_in_days(cls, start, end):
        difference = end - start
        difference = math.ceil(difference / 1000 / 60 / 60 / 24)
        return difference

    @classmethod
    def get_different_timemillis_in_months(cls, start, end):
        difference = end - start
        difference = math.floor(difference / 1000 / 60 / 60 / 24 / 30)
        return difference
    
    @classmethod
    def get_future_time_from_current_date_time(cls, date_time, second=0, minute=0, hour=0, day=0):
        return date_time + timedelta(seconds=second, minutes=minute, hours=hour, days=day)

    @classmethod
    def get_past_time_from_current_date_time(cls, date_time, second=0, minute=0, hour=0, day=0):
        return date_time - timedelta(seconds=second, minutes=minute, hours=hour, days=day)
    
    @classmethod
    def count_hours(cls, time_millis_in, time_millis_out):
        flag = int(cls.get_different_timemillis_in_minutes(time_millis_in, time_millis_out))
        hours = 1

        if flag > 60:
            hours = cls.get_different_timemillis_in_hours(time_millis_in, time_millis_out)

            # hours return float value, we need to round up the value. e.g: 1.45 -> 2
            hours = math.ceil(hours)

        return hours
    
    @classmethod
    def count_days(cls, time_millis_in, time_millis_out):
        flag = int(cls.get_different_timemillis_in_hours(time_millis_in, time_millis_out))
        days = 1

        if flag > 24:
            days = cls.get_different_timemillis_in_days(time_millis_in, time_millis_out)

            # days return float value, we need to round up the value. e.g: 1.45 -> 2
            days = math.ceil(days)

        return days
    
    @classmethod
    def count_hours_with_data(cls, time_in, time_out):
        total_minutes = int(cls.get_different_timemillis_in_minutes(time_in, time_out))
        hours = 1
        
        data = {"hours": 0, "minutes": total_minutes, "count": 1, "real_count": 1, "round_up": 1}

        if total_minutes > 60:
            # Get hours with floor division
            _hours = total_minutes // 60
            # Get additional minutes with modulus
            _minutes = total_minutes % 60

            hours = cls.get_different_timemillis_in_hours_without_ceil(time_in, time_out)
            round_up_hours = cls.get_different_timemillis_in_hours(time_in, time_out)

            data = {"hours": _hours, "minutes": _minutes, "count": hours, "real_count": hours, "round_up": round_up_hours}

        return data
    
    @classmethod
    def get_date_time_by_timezone(cls, date_time: datetime, different_hours: int = 0, format="%Y-%m-%d %H:%M:%S"):
        tz = timezone(timedelta(hours=different_hours))
        return date_time.astimezone(tz).strftime(format)

    @staticmethod
    def get_curfew_hours_array(overstay_time_start):
        start = int(overstay_time_start.replace(
            ' ', ',').split('-')[0].split(':')[0])
        end = int(overstay_time_start.replace(
            ' ', ',').split('-')[1].split(':')[0])
        if start > end:
            overstay_start = DateTimeHelper.get_string_datetime_date_with_time(format='%Y-%m-%d ')+(overstay_time_start).replace(' ', '').split('-')[0]+':00'
            overstay_end = DateTimeHelper.parse_date_to_string(DateTimeHelper.time_future(day=1), format='%Y-%m-%d ') + (overstay_time_start).replace(' ', '').split('-')[1]+':00'
        else:
            overstay_start = DateTimeHelper.get_string_datetime_date_with_time(format='%Y-%m-%d ')+(overstay_time_start).replace(' ', '').split('-')[0]+':00'
            overstay_end = DateTimeHelper.parse_date_to_string(DateTimeHelper.get_datetime_now(), format='%Y-%m-%d ') + (overstay_time_start).replace(' ', '').split('-')[1]+':00'
    
        hour_array = DateTimeHelper.get_hour_array(start=overstay_start, end=overstay_end)
        return hour_array
    

