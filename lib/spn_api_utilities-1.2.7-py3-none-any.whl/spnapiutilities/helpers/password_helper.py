from spnapiutilities.helpers.crypto import CryptoHelper

class PasswordHelper:
    
    @classmethod
    def hash_md5(cls, text):
        return CryptoHelper.hash_md5(text)
    
    @classmethod
    def compare_md5(cls, hashed, text):
        return hashed == cls.hash_md5(text)
