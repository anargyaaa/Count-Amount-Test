import hashlib

class CryptoHelper:

    @classmethod
    def hash_md5(cls, text):
        return str(hashlib.md5(bytes(str(text).encode('utf-8'))).hexdigest())
