from calendar import monthrange
from datetime import date, datetime, timedelta, timezone
from typing import List
import copy

class DateTimeHelper:
    """
        Normal Time Area
    """
    @classmethod
    def get_datetime_now(cls):
        return datetime.now()
    
    @classmethod
    def get_string_datetime_date_only(cls):
        return str(cls.get_datetime_now().strftime("%Y-%m-%d"))
    
    @classmethod
    def get_string_datetime_month_and_year_only(cls):
        return str(cls.get_datetime_now().strftime("%Y-%m"))
    
    @classmethod
    def get_string_datetime_month_only(cls):
        return str(cls.get_datetime_now().strftime("%m"))

    @classmethod
    def time_future(date=None, second=0, minute=0, hour=0, day=0):
        from app import Config

        date_system = datetime.utcnow()

        if Config['APP_ENV'] in ['development', 'dev', 'test', 'local']:
            date_system = datetime.now()

        ts = date_system if date is None else date
        return ts + timedelta(seconds=second, minutes=minute, hours=hour, days=day)

    @classmethod
    def parse_date_to_string(date_time, format='%Y-%m-%d %H:%M:%S'):
        return datetime.strftime(date_time, format)

    @classmethod
    def get_string_datetime_year_only(cls):
        return str(cls.get_datetime_now().strftime("%Y"))
    
    @classmethod
    def get_string_datetime_date_with_time(cls):
        return str(cls.get_datetime_now().strftime("%Y-%m-%d %H:%M:%S"))
    
    @classmethod
    def get_string_datetime_hours(cls):
        return str(cls.get_datetime_now().strftime("%Y-%m-%d %H"))
    
    @classmethod
    def get_string_datetime_with_hours_and_minutes(cls):
        return str(cls.get_datetime_now().strftime("%Y-%m-%d %H:%M"))
    
    @classmethod
    def get_datetime_unix(cls):
        return int(cls.get_datetime_now().timestamp())
    
    """
        UTC Area
    """
    @classmethod
    def get_datetime_from_utc(cls):
        return datetime.utcnow()
    
    @classmethod
    def get_string_datetime_date_only_from_utc(cls):
        return str(cls.get_datetime_from_utc().strftime("%Y-%m-%d"))
    
    @classmethod
    def get_string_datetime_date_with_time_from_utc(cls):
        return str(cls.get_datetime_from_utc().strftime("%Y-%m-%d %H:%M:%S"))
    
    @classmethod
    def get_string_datetime_hours_from_utc(cls):
        return str(cls.get_datetime_from_utc().strftime("%Y-%m-%d %H"))
    
    @classmethod
    def get_string_datetime_with_hours_and_minutes_from_utc(cls):
        return str(cls.get_datetime_from_utc().strftime("%Y-%m-%d %H:%M"))
    
    @classmethod
    def get_datetime_unix_from_utc(cls):
        return int(cls.get_datetime_from_utc().timestamp())
    
    @classmethod
    def get_string_datetime_month_and_year_only_from_utc(cls):
        return str(cls.get_datetime_from_utc().strftime("%Y-%m"))
    
    @classmethod
    def get_string_datetime_month_only_from_utc(cls):
        return str(cls.get_datetime_from_utc().strftime("%m"))
    
    @classmethod
    def get_string_datetime_year_only_from_utc(cls):
        return str(cls.get_datetime_from_utc().strftime("%Y"))
    
    @classmethod
    def get_current_millisecond(cls):
        date = cls.get_datetime_now().timestamp()
        return int(round(date * 1000))
    
    @classmethod
    def get_current_millisecond_from_utc(cls):
        date = cls.get_datetime_from_utc().timestamp()
        return int(round(date * 1000))

    @classmethod
    def get_datetime_fromtimestamp(cls, timestamp: int, zone: timezone = timezone.utc):
        '''
        returns datetime object from millis input and 
        convert it into the timezone input
        '''
        return datetime.fromtimestamp(timestamp / 1000.0, tz=zone)

    @classmethod
    def parse_string_to_date_time(cls, date_time_string, format='%Y-%m-%d %H:%M:%S'):
        return datetime.strptime(date_time_string, format)
    
    @classmethod
    def get_date_time_from_millisecond(cls, timemillis: int = 0, format='%Y-%m-%d %H:%M:%S', not_string=False):
        result = datetime.fromtimestamp(int(timemillis) / 1000.0)
        if not_string:
            return result
        return result.strftime(format)

    @classmethod
    def get_millisecond_from_date_time(cls, date_time, format='%Y-%m-%d %H:%M:%S'):
        if type(date_time) == str:
            date_time = cls.parse_string_to_date_time(date_time, format)
        millisecond = date_time.timestamp()
        return int(round(millisecond * 1000))

    
    @classmethod
    def get_future_from_timemillis_in_hour(cls, timemillis: int, hours: int = 1):
        hours_in_millis = hours * 60 * 60 * 1000
        new_millis = timemillis + hours_in_millis
        return new_millis
    
    @classmethod
    def get_future_return_timemillis(cls, date=None, second=0, minute=0, hour=0, day=0):
        cur = date if date else datetime.utcnow()
        future = cur + timedelta(
            seconds=second, minutes=minute,
            hours=hour, days=day
        )
        return int(future.timestamp() * 1000)


    @classmethod
    def get_past_return_timemillis(cls, date=None, second=0, minute=0, hour=0, day=0):
        cur = date if date else datetime.utcnow()
        future = cur - timedelta(
            seconds=second, minutes=minute,
            hours=hour, days=day
        )
        return int(future.timestamp() * 1000)

    @classmethod
    def get_future_return_date(cls, date=None, second=0, minute=0, hour=0, day=0):
        cur = date if date else datetime.utcnow()
        return cur + timedelta(seconds=second, minutes=minute, hours=hour, days=day)

    @classmethod
    def get_past_return_date(cls, date=None, second=0, minute=0, hour=0, day=0):
        cur = date if date else datetime.utcnow()
        return cur - timedelta(seconds=second, minutes=minute, hours=hour, days=day)

    @classmethod
    def get_future_from_timemillis_detail(cls, timemillis: int, hours: int = 1, minutes: int = 0, seconds: int = 0):
        hours_in_millis = hours * 60 * 60 * 1000
        minutes_in_millis = minutes * 60 * 1000
        seconds_in_millis = seconds * 1000

        new_millis = timemillis + hours_in_millis + minutes_in_millis + seconds_in_millis
        return new_millis

    @classmethod
    def get_hour_array(start, end, format='%H:%M:00'):
        # try:
        hour_array = []
        if start and end:
            end = end if isinstance(end, datetime) else stringToDateTime(end)
            start = start if isinstance(
                start, datetime) else stringToDateTime(start)
            while (start <= end):
                start_string = parseDateToString(start, format=format)
                hour_array.append(start_string)
                start += timedelta(minutes=1)
        return hour_array


    @staticmethod
    def get_list_of_days_month_in_range(start, end, fmt='%Y-%m-%d %H:%M:%S', to_fmt='%Y-%m-%d'):
        start = datetime.strptime(start, fmt)
        end = datetime.strptime(end, fmt)
    
        list_date = []
    
        for x in range(0, (end-start).days):
            date = (start + timedelta(days=x)).strftime(to_fmt)
            list_date.append(date)
    
        return list_date

    @staticmethod
    def get_rack_location(location):
        length = len(location)
        module = 1
        if length <= 2:
            label = location[0:1]
            floor = location[1:2]
        elif length <= 4:
    
            label = location[0:1]
            floor = location[1:3]
            if location[0].isdigit():
                module = location[0]
                label = location[1]
                floor = location[2:]
        else:
            raise Exception("Maximum length is 3!")
    
        return {
            "module": module,
            "label": label,
            "floor": floor,
        }

    @staticmethod
    def is_date_in_period(date_to_check: datetime, periodes: List[list]) -> list:
        """
        O(n log n)
        return list of start and end shift if match

        [7,15] [15,22] [22,31]

        pointer --> 2020-07-07 06.35 -> 1594078500000

        2020-07-07 07:00 -> 1594080000000
        2020-07-07 15:00 -> 1594108800000

        2020-07-07 15:00 -> 1594108800000
        2020-07-07 22:00 -> 1594134000000

        2020-07-07 22:00 -> 1594134000000
        2020-07-08 07:00 -> 1594166400000
        
        6.35 ?
        """

        # sort
        sorted_periodes = sorted(periodes, key=lambda x: x[0], reverse=False)
        labels = copy.deepcopy(sorted_periodes)

        now_date = datetime.now()
        yesterday_date = (now_date - timedelta(days=1)).strftime("%Y-%m-%d")
        tommorow_date = (now_date + timedelta(days=1)).strftime("%Y-%m-%d")
        current_date = now_date.strftime("%Y-%m-%d")

        # O(n) depends on how many periodes
        for period in sorted_periodes:
            period.extend([0,0])
            # reformat O(2)
            for step in range(0,2):
                if period[step] < 0:
                    # reformat yesterday shift
                    period[step] += 24
                    period[step + 2] = datetime.strptime(f"{yesterday_date} {period[step]}:00", '%Y-%m-%d %H:%M').timestamp() * 1000
                elif period[step] >= 24:
                    # reformat tommorow shift
                    period[step] -= 24
                    period[step + 2] = datetime.strptime(f"{tommorow_date} {period[step]}:00", '%Y-%m-%d %H:%M').timestamp() * 1000
                else:
                    # reformat today shift
                    period[step + 2] = datetime.strptime(f"{current_date} {period[step]}:00", '%Y-%m-%d %H:%M').timestamp() * 1000
            # O(3)
            for day in [yesterday_date, current_date, tommorow_date]:
                matcher = datetime.strptime(f"{day} {date_to_check.strftime('%H:%M:%S')}", "%Y-%m-%d %H:%M:%S") 
                if period[2] < matcher.timestamp() * 1000 <= period[3]:
                    return labels[sorted_periodes.index(period)]
            
        return []
    
    
