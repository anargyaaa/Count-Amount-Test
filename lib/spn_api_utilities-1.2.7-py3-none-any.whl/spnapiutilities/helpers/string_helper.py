import locale
import random
import re
import string


class StringHelper:
    
    @classmethod
    def generate_secret_key(cls, size=16):
        chars = string.ascii_uppercase + string.digits + "`~@#$%^*(){}|:<>,.[]=_-"
        return ''.join(random.choice(chars) for _ in range(size))
    
    @classmethod
    def generate_secret_key_alphanumeric_only(cls, size=16):
        chars = string.ascii_uppercase + string.digits
        return ''.join(random.choice(chars) for _ in range(size))
    
    @classmethod
    def transform_image_url(cls, bucket="spn-gate", image=""):
        return f"https://{bucket}.s3-ap-southeast-1.amazonaws.com/{image}"
    
    @classmethod
    def convert_period_to_indonesia(cls, period):
        if period == "month":
            return "bulan"
        elif period == "year":
            return "tahun"
        elif period == "day":
            return "hari"
        elif period == "hour":
            return "jam"
        elif period == "minute":
            return "menit"
        
    @classmethod
    def get_text_alphanumeric_only(cls, string):
        return re.sub(r'\W+', '', str(string))
    
    @classmethod
    def remove_whitespace(cls, string):
        return string.strip().replace(" ", "")

    @classmethod
    def replace_text_with_star(cls, text):
        text = str(text).split(" ")
        new_text = []
        for item in text:
            text_length = len(item)

            if text_length > 3:
                new = item[0:3]
            else:
                new = item[0:2]

            counting = text_length - len(new)
            for i in range(0, counting):
                new += "*"

            new_text.append(new)

        return " ".join(new_text)
    
    @classmethod
    def rupiah_format_currency(cls, format_currency="Rp. ", amount=0):
        locale.setlocale(locale.LC_ALL, 'id_ID')

        amount = str(locale.currency(amount, grouping=True))
        amount = f"Rp {amount[2:]}" # Gives space between Rp and balance
        size = len(amount)
        amount = amount[:size-3] # Remove ,00

        return amount        

    @classmethod
    def format_rupiah(cls, amount):
        rupiah = "Rp {:,.2f}".format(amount).replace(",", ".")
        return rupiah

    @classmethod
    def censor_name(full_name):
        full_name = str(full_name).split(" ")
        new_name = []
        for item in full_name:
            name_length = len(item)

            if name_length > 3:
                new = item[0:3]
            else:
                new = item[0:2]

            counting = name_length - len(new)
            for i in range(0, counting):
                new += "*"

            new_name.append(new)

        return " ".join(new_name)

    @staticmethod
    def alphanumeric_only(words):
        return re.sub(r'\W+', '', words)

    @staticmethod
    def convertPeriodToIndonesian(period):
        if period == "month":
            return "bulan"
        elif period == "year":
            return "tahun"
        elif period == "day":
            return "hari"
        elif period == "hour":
            return "jam"
        elif period == "minute":
            return "menit"

    @staticmethod
    def currencyFormat(currency, amount):
        return "{}{:,.2f}".format(currency, amount)

    @staticmethod
    def secretKeyGenerator(size=16):
        chars = string.ascii_uppercase + string.digits + "`~@#$%^*(){}|:<>,.[]=_-"
        return ''.join(random.choice(chars) for _ in range(size))

    def split_image(image):
        import os
        data = os.path.split(image)

        return {
            'image': data[1],
            'image_path': data[0]
        }
