import json

def mappingXYZ(tower):
    alphabet = "A"
    tower =  tower if isinstance(tower,dict) else json.loads(tower)
    x,y,z = int(tower['x']['value']), int(tower['y']['value']), int(tower['z']['value'])
    x = x if x > 0 or x < 18 else 1
    tower['z']["list"]=[str(i) for i in range(1,z+1)]
    tower['x']["list"]=[chr(ord(alphabet)+i) for i in range(0, x)]
    tower['y']["list"]=[str(i) for i in range(1, y+1)]

    return tower
