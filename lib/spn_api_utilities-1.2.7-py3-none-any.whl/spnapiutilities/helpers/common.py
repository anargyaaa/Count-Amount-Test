from typing import Union

def isEmpty(param) -> bool:
    if param is None or len(str(param)) < 1:
        return True
    else:
        return False

def keyExist(key: str, data: dict, replace: any=None) -> any:
    """
    check if key exist in dict
    if replace param exist return replacable data
    """
    if key not in data:
        if replace:
            return replace
        return False

    return True
