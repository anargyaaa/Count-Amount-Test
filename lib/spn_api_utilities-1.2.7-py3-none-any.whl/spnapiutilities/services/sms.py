from spnapiutilities.services.loger import Logger
from twilio.rest import Client
from twilio.base.exceptions import TwilioRestException

class SMSTwilio:
    def __init__(self, account_sid, auth_token, twilio_number):
        self.twilio_number = twilio_number
        self.twilio_number = twilio_number
        self.client = Client(account_sid, auth_token)

    def sendSMS(self, phone, message):
        try:
            message = self.client.messages.create(
                to=phone,
                from_=self.twilio_number, 
                body=message,
            )
            return message
        except TwilioRestException as e:
            Logger(Logger.ERROR).write(e)
