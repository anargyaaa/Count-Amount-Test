from app import mail
from flask_mail import Message
from app.extensions import mail as lib_mail
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail as SGMail
from sendgrid.helpers.mail import Attachment, FileContent, FileName, FileType, Disposition
import os
import base64
from spnapiutilities.services.loger import Logger

class Mail(object):
    def __init__(self, recipient, subject, template, sendgrid_api_key=""):
        self.recipient = recipient  # Should be array
        self.subject = subject
        self.template = template
        self.sender = 'no-reply@soulparking.co.id'
        self.sendgrid_api_key = sendgrid_api_key

    def send(self, attachment=None, type_file="text/csv", html=True):

        if self.sendgrid_api_key:
            return self.sendViaSendgrid(attachment, type_file, html)

        msg = Message(self.subject, sender=self.sender, recipients=self.recipient)
        msg.html = self.template
        mail.send(msg)

    def sendViaSendgrid(self, attachment=None, type_file="text/csv", html=True):

        msg = Message(self.subject, sender=self.sender, recipients=self.recipient)
        
        if html:
            msg.html = self.template
        else:
            msg.body = self.template
        
        if attachment:
            dir, name = os.path.split(attachment)
            with open(attachment, 'r', newline='') as fp:
                msg.attach(name, type_file, fp.read())
        
        try:
            lib_mail.send(msg)
        except Exception as e:
            Logger(Logger.ERROR).write(e)

    def sendUsingSendGrid(self, attachment=None, type_file="text/csv", html=True):
        if type(self.recipient) == list:
            recipients = self.recipient
        else:
            recipients = ",".join(self.recipient)
            
        if html:
            message = SGMail(
                from_email=self.sender,
                to_emails=recipients,
                subject=self.subject,
                html_content=self.template
            )
        else:
            message = SGMail(
                from_email=self.sender,
                to_emails=recipients,
                subject=self.subject,
                plain_text_content=self.template
            )
        
        if attachment:
            with open(attachment, 'rb') as fp:  
                data = fp.read()
                fp.close()
            encoded_file = base64.b64encode(data).decode()

            dir, name = os.path.split(attachment)
            attachedFile = Attachment(
                FileContent(encoded_file),
                FileName(name),
                FileType(type_file),
                Disposition('attachment')
            )
            message.attachment = attachedFile

        try:
            sg = SendGridAPIClient(self.SENDGRID_API_KEY)
            response = sg.send(message)
            Logger(Logger.INFO).write(response.status_code)
            Logger(Logger.INFO).write(response.body)
            Logger(Logger.INFO).write(response.headers)
        except Exception as e:
            Logger(Logger.ERROR).write(e)
