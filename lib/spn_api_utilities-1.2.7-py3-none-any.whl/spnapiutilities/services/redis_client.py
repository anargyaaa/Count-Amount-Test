from datetime import timedelta
import json
import os
import redis

class RedisClient():
    def __init__(
            self, 
            host="localhost", 
            port="6379", 
            db="zero", 
            password="", 
            channel_name="",
        ):
        self.host = host
        self.db = db
        self.port = port
        self.pubsub = None
        self.channel = channel_name
        self.password = password

        if os.environ["FLASK_CONFIG"] == "test":
            self.initialize_test_db()
            return

        self.intialize_production_db()

    def initialize_test_db(self):
        import fakeredis
        self.redis = fakeredis.FakeStrictRedis(version=6)

    def intialize_production_db(self):
        self.redis = redis.Redis(
            host=self.host, 
            db=self.db,
            port=self.port,
            password=self.password,
        )

    def write(self, key, value):
        self.redis.mset({key: value})
        return True

    def set(self, key, value, expired=None, dumps_json=None):
        if dumps_json:
            value = json.dumps(value)
        self.redis.set(key, value, ex=expired)
        return True

    def setExpire(self, key, expired=timedelta(hours=72)):
        self.redis.expire(key, time=expired)

    def set_lpush(self, key, value):
        data = self.redis.lpush(key, value)
        return f"list length: {data}"

    def set_rpush(self, key, value):
        data = self.redis.rpush(key, value)
        return f"list length: {data}"

    def set_hash(self, key, field_name, value):
        data = self.redis.hset(key, field_name, value)
        return data

    def set_multiple_hash(self, key, value):
        data = self.redis.hmset(key, value)
        return data

    def get_single_hash(self, key, field_name, as_dict=False):
        result = self.redis.hget(key, field_name)

        if not result:
            return False

        result = result.decode("utf-8")
        if as_dict:
            result = json.loads(result)

        return result

    def get_all_hash(self, key, as_dict=None):
        result = self.redis.hgetall(key)

        if not result:
            return False

        if as_dict:
            result = json.loads(result)

        return result

    def get_position_list(self, key, value):
        return self.redis.lpos(key, value)

    def set_list_at_index(self, key, index, value):
        data = self.redis.lset(key, index, value)
        return f"list length: {data}"

    def read_list(self, key, start, end, load_json=None):
        result = self.redis.lrange(key, start, end)
        if result:
            return result
        return False

    def remove_list_item(self, key, count, value):
        result = self.redis.lrem(key, count, value)
        if result:
            return result
        return False

    def pop_last_item(self, key):
        result = self.redis.rpop(key)
        if result:
            return result
        return False

    def read(self, key, load_json=None):
        result = self.redis.get(key)
        if result:
            result = result.decode("utf-8")
            if load_json:
                result = json.loads(result)
            return result
        else:
            return False

    def get(self, key):
        return self.redis.get(key)

    def getKeyByPrefix(self, prefix):
        array = []
        for key in self.redis.scan_iter(prefix+"*"):
            key = key.decode("utf-8")
            key = key.replace(prefix, '').replace(":expired", '')
            array.append(key)

        return list(dict.fromkeys(array))

    def delete(self, key):
        self.redis.delete(key)
        return True

    def connect(self):
        self.pubsub = self.redis.pubsub(ignore_subscribe_messages=True)
        self.pubsub.subscribe(self.channel)

    def publish(self, message):
        self.redis.publish('spn-gate', message)

    def hash_increment(self, redis_key, key_name):
        return self.redis.hincrby(redis_key, key_name)

    def hash_decrement(self, redis_key, key_name):
        return self.redis.hincrby(redis_key, key_name, amount=-1)

    def increment(self, key):
        self.redis.incr(key)

    def decrement(self, key):
        self.redis.decr(key)

    def pipeline(self):
        return self.redis.pipeline()
