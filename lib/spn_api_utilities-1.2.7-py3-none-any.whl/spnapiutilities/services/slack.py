import requests

class SlackWebhookSender:
    def __init__(self, webhookUrl):
        self.slack_webhook = webhookUrl

    def slackWebhook(self, msg):
        return requests.post(self.slack_webhook, json={"text": msg})
