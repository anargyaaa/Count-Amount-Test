import base64
import logging
import boto3
from app.library.utility import transformImageUrl
from botocore.exceptions import ClientError
from config import Config
from werkzeug.datastructures import FileStorage
from werkzeug.utils import secure_filename
from typing import Union
from spnapiutilities.services.loger import Logger
from spnapiutilities.helpers.crypto import CryptoHelper

def getResource(bucket, key, filename):
    s3 = boto3.client("s3")

    try:
        file = s3.download_file(
            Bucket=bucket,
            Key=key,
            Filename=filename)

    except ClientError as e:
        Logger(Logger.ERROR).write(e)
        return None
    return file


def create_presigned_url(
        bucket_name, 
        object_name, 
        expiration=3600, 
        method="get_object",
    ):
    """Generate a presigned URL to share an S3 object

    :param bucket_name: string
    :param object_name: string
    :param expiration: Time in seconds for the presigned URL to remain valid
    :return: Presigned URL as string. If error, returns None.
    """

    http_method = "POST"

    if method == "put_object":
        http_method = "PUT"

    # Generate a presigned URL for the S3 object
    s3_client = boto3.client('s3')
    try:
        response = s3_client.generate_presigned_url(
            ClientMethod=method, Params={
                'Bucket': bucket_name, 'Key': object_name},
            ExpiresIn=expiration, HttpMethod=http_method
        )
    except ClientError as e:
        Logger(Logger.ERROR).write(e)
        return None

    # The response contains the presigned URL
    return response


def upload(bucket_name, image, image_path):
    s3_client = boto3.resource('s3')
    try:
        s3_client.Bucket(bucket_name).put_object(
            Key=image_path,
            Body=base64.b64decode(
                image),
            ContentType='image/png',
            ACL='public-read')

        return transformImageUrl(image_path)
    except ClientError as e:
        Logger(Logger.ERROR).write(e)
        raise e


def create_presigned_post(
    bucket_name, 
    object_name,
    fields=None, 
    conditions=None, 
    expiration=3600,
    ):
    """Generate a presigned URL S3 POST request to upload a file

    :param bucket_name: string
    :param object_name: string
    :param fields: Dictionary of prefilled form fields
    :param conditions: List of conditions to include in the policy
    :param expiration: Time in seconds for the presigned URL to remain valid
    :return: Dictionary with the following keys:
        url: URL to post to
        fields: Dictionary of form fields and values to submit with the POST
    :return: None if error.
    """
    # Generate a presigned S3 POST URL
    s3_client = boto3.client('s3')
    try:
        response = s3_client.generate_presigned_post(
            bucket_name,
            object_name,
            Fields=fields,
            Conditions=conditions,
            ExpiresIn=expiration,
        )
    except ClientError as e:
        Logger(Logger.ERROR).write(e)
        return None

    # The response contains the presigned URL and required fields
    return response


def create_multipart_static_file(bucket, file_name):
    return boto3.client('s3').create_multipart_upload(Bucket=bucket, Key=file_name)


def upload_part_static_file(
        bucket,  
        file_name, 
        upload_id: str = "", 
        part_number: int = 1, 
        chunked_files: bytes = None,
    ):
    response = boto3.client('s3').upload_part(
        Bucket=bucket, Key=file_name,
        UploadId=upload_id, PartNumber=part_number,
        Body=chunked_files)

    return {'e_tag': response['ETag'], 'part_number': part_number}


def complete_multipart_upload_static_file(
        bucket, 
        file_name, 
        upload_id: str = "", 
        parts: list = [],
    ):
    return boto3.client('s3').complete_multipart_upload(
        Bucket=bucket, Key=file_name,
        UploadId=upload_id, MultipartUpload={'Parts': parts})


def upload_file_from_local(bucket=Config.BUCKET, file_path="", filename=""):
    s3 = boto3.resource('s3')
    return s3.meta.client.upload_file(file_path, bucket, filename)

def upload_file(filename, bucket=None):
    from app import Config as cf
    if bucket is None:
        bucket = cf['BUCKET']
    boto = boto3.client('s3')
    with open(filename, 'rb') as data:
        boto.upload_fileobj(data, bucket, filename)

def read_file_from_s3(bucket=Config.BUCKET, file_path="", filename=""):
    s3 = boto3.client('s3')
    return s3.get_object(file_path, bucket, filename)


def upload_file_obj(
        file: FileStorage, 
        bucket=Config.BUCKET,
        subPath: str = '',
    ) -> Union[bool, str]:
    filename = secure_filename(file.filename)
    
    # hash filename
    filename = f"{CryptoHelper.hash_md5(filename)}.{file.filename.split('.')[-1]}"

    if subPath != '':
        filename = f"{subPath}/{filename}"

    try:
        boto = boto3.client('s3')
        boto.upload_fileobj(file, bucket, filename)

    except Exception as e:
        Logger(Logger.ERROR).write(e)
        return False
    
    return filename

def deleteFileObject(fileName: str, bucket=Config.BUCKET):
    try:
        boto = boto3.client('s3')
        boto.delete_object(bucket, fileName)
    except Exception as e:
        Logger(Logger.ERROR).write(e)
        return False
    
