import datetime
import logging
import os.path

class Logger:
    ERROR = "error"
    INFO = "info"

    def __init__(self, type="info"):
        self.logger = logging.getLogger()
        self.logger.handlers.clear()
        self.type = type

        self.LEVEL = None
        self.PATH = None
        self.LOGGER_FUNCTION = None
        self.EXEC_INFO = False

    def write(self, messages, data=None):
        from app import Config

        if self.type == "error":
            self.LEVEL = logging.ERROR
            self.PATH = f"{Config['LOG_PATH']}/errors/"
            self.LOGGER_FUNCTION = self.logger.error
            self.EXEC_INFO = True
        elif self.type == "info":
            self.LEVEL = logging.INFO
            self.PATH = f"{Config['LOG_PATH']}/info/"
            self.LOGGER_FUNCTION = self.logger.info
            self.EXEC_INFO = False

        self.logger.setLevel(self.LEVEL)
        filename = '{}{}.log'.format(self.PATH, Config['LOG_FILE'] if Config['LOG_FILE'] else datetime.date.today())

        if not os.path.isfile(filename):
            open(filename, "w+")

        ch = logging.FileHandler(filename=filename)
        ch.setLevel(self.LEVEL)
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        ch.setFormatter(formatter)
        self.logger.addHandler(ch)
        self.LOGGER_FUNCTION(messages, exc_info=self.EXEC_INFO)

