from multiprocessing.sharedctypes import Value
import requests
import json
from requests.models import HTTPError

class ApiService(object):
    def __init__(self, config=None, headers=None):
        if not config:
            raise ValueError("Config cannot be null!")
        
        if not config.get('base_url'):
            raise ValueError("Base URL must be set! Example: https://api.soulparking.co.id")

        self.config = config
        self.headers = {
            "Authorization": self.config.get('authorization'),
        }

        if headers:
            self.headers.update(headers)

        self.response = None

    def validate_return(self):
        if self.response.status_code != requests.codes.ok and self.config.get('validate'):
            text = str(self.response.text)
            raise HTTPError("Error: {}".format(text))
        
        return self.response.json()

    def get_url(self, url, not_origin_uri=False):
        if not_origin_uri:
            return url
        
        # Ensure the first word of url is slash
        if url[0:1] != "/":
            url = "/" + url

        return self.config.get('base_url') + url

    def json_data(self, data=None):
        if data:
            self.headers["Content-Type"] = "application/json"
            data = json.dumps(data)
            
        return data

    def get_request(self, url, not_origin_uri=False):
        self.response = requests.get(self.get_url(url, not_origin_uri=not_origin_uri), headers=self.headers, timeout=self.config.get('timeout'))

        return self.validate_return()

    def post_request(self, url, data=None, files=None, not_origin_uri=False):
        self.response = requests.post(
            self.get_url(url, not_origin_uri=not_origin_uri), 
            data=self.json_data(data), 
            files=files, 
            headers=self.headers, 
            timeout=self.config.get('timeout')
        )

        return self.validate_return()
    
    def put_request(self, url, data, not_origin_uri=False):
        self.response = requests.put(self.get_url(url, not_origin_uri=not_origin_uri), data=self.json_data(data), headers=self.headers, timeout=self.config.get('timeout'))

        return self.validate_return()
    
    def delete_request(self, url, data, not_origin_uri=False):
        self.response = requests.delete(self.get_url(url, not_origin_uri=not_origin_uri), data=self.json_data(data), headers=self.headers, timeout=self.config.get('timeout'))

        return self.validate_return()

    def patch_request(self, url, data, not_origin_uri=False):
        self.response = requests.patch(self.get_url(url, not_origin_uri=not_origin_uri), data=self.json_data(data), headers=self.headers, timeout=self.config.get('timeout'))

        return self.validate_return()