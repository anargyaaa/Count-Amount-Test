from pyfcm import FCMNotification

class FCMSender:

    def __init__(
            self, 
            type, 
            payload, 
            app="user", 
            fcm_key=None,
            icon="ic_soulparking_only",
            sound="spn_ringtone.aiff", 
            channelId="spn-user",
        ):
        self.payload = payload
        self.type = type
        self.icon = icon
        self.sound = sound
        self.android_channel_id = channelId
        self.api_key = self.getFCMKey(app) if fcm_key is None else fcm_key
        self.push_service = FCMNotification(api_key=self.api_key)

    def push(self):
        if self.type == "single":
            self.payload['registration_id'] = [
                self.payload.get('registration_id')]

        return self.multiple()

    def multiple(self):
        registration_ids = self.payload.get('registration_id')
        message_title = self.payload.get('title')
        message_body = self.payload.get('body')
        data_message = self.payload.get('data')
        extra_notification_kwargs = self.payload.get(
            'extra') if 'extra' in self.payload else {}
        click_action = self.payload.get(
            'click_action') if 'click_action' in self.payload else None

        result = self.push_service\
                .notify_multiple_devices(
                    registration_ids=registration_ids,
                    message_title=message_title, 
                    message_body=message_body,
                    data_message=data_message,
                    extra_notification_kwargs=extra_notification_kwargs,
                    click_action=click_action, 
                    message_icon=self.icon,
                    sound=self.sound,
                    android_channel_id=self.android_channel_id,
                )

        return result

