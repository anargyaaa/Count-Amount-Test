from datetime import datetime
from unittest import TestCase
from spnapiutilities.helpers.datetime_helper import DateTimeHelper
from spnapiutilities.helpers.common import isEmpty, keyExist

class TestDictionary(TestCase):
    def setUp(self):
        self.cur_date = datetime.now()
        return super().setUp()

    def test_is_empty(self):
        obj = {}
        self.assertIs(isEmpty(None), True)
        self.assertIs(isEmpty(""), True)
        self.assertIs(isEmpty(obj), False)

    def test_key_exist_in_dict(self):
        payload = {
            "year": 2023,
            "month": "june",
        }

        self.assertIs(keyExist("year", payload), True)
        self.assertIs(keyExist("day", payload), False)
        self.assertIs(keyExist("day", payload, "Monday"), "Monday")


    

   
