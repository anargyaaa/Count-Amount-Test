from unittest import TestCase
from spnapiutilities.helpers.string_helper import StringHelper

class TestString(TestCase):
    def test_get_convert_month_period_to_indonesia(self):
        month = StringHelper.convert_period_to_indonesia("month")
        assert month == "bulan"

    def test_get_convert_year_period_to_indonesia(self):
        year = StringHelper.convert_period_to_indonesia("year")
        assert year == "tahun"

    def test_get_convert_day_period_to_indonesia(self):
        day = StringHelper.convert_period_to_indonesia("day")
        assert day == "hari"

    def test_get_convert_hour_period_to_indonesia(self):
        hour = StringHelper.convert_period_to_indonesia("hour")
        assert hour == "jam"

    def test_get_convert_minute_period_to_indonesia(self):
        hour = StringHelper.convert_period_to_indonesia("minute")
        assert hour == "menit"

    def test_remove_whitespace(self):
        text = StringHelper.remove_whitespace("welcome to SPN")
        counter = 0
        for i in range(0, len(text)):
            if text[i] == "":
                counter += 1
        assert text == "welcometoSPN"
        assert counter == 0

    def test_transform_image_url(self):
        url = StringHelper.transform_image_url(image="test.jpg")
        assert url == f"https://spn-gate.s3-ap-southeast-1.amazonaws.com/test.jpg"