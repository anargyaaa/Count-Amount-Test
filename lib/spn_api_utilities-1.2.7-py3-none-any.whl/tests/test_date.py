"""test_class_parametrization.py"""
from datetime import datetime
from unittest import TestCase
from spnapiutilities.helpers.datetime_helper import DateTimeHelper

class TestDate(TestCase):
    def setUp(self):
        self.cur_date = datetime.now()
        return super().setUp()
    
    def test_get_current_date(self):
        n = DateTimeHelper.get_datetime_now()
        self.assertEqual(type(n), datetime)
        
    def test_get_string_datetime_date_only(self):
        n = DateTimeHelper.get_string_datetime_date_only()
        
        cur_date = self.cur_date.strftime("%Y-%m-%d")
        
        self.assertEqual(type(n), str)
        self.assertEqual(cur_date, n)
        
    def test_get_string_datetime_month_and_year_only(self):
        n = DateTimeHelper.get_string_datetime_month_and_year_only()
        
        cur_date = self.cur_date.strftime("%Y-%m")
        
        self.assertEqual(type(n), str)
        self.assertEqual(cur_date, n)
        
    def test_get_string_datetime_month_only(self):
        n = DateTimeHelper.get_string_datetime_month_only()
        
        cur_date = self.cur_date.strftime("%m")
        
        self.assertEqual(type(n), str)
        self.assertEqual(cur_date, n)
        
    def test_get_string_datetime_year_only(self):
        n = DateTimeHelper.get_string_datetime_year_only()
        
        cur_date = self.cur_date.strftime("%Y")
        
        self.assertEqual(type(n), str)
        self.assertEqual(cur_date, n)
        
    def test_get_string_datetime_date_with_time(self):
        n = DateTimeHelper.get_string_datetime_date_with_time()
        
        cur_date = self.cur_date.strftime("%Y-%m-%d %H:%M:%S")
        
        self.assertEqual(type(n), str)
        self.assertEqual(cur_date, n)
        
    def test_get_string_datetime_hours(self):
        n = DateTimeHelper.get_string_datetime_hours()
        
        cur_date = self.cur_date.strftime("%Y-%m-%d %H")
        
        self.assertEqual(type(n), str)
        self.assertEqual(cur_date, n)
        
    def test_get_string_datetime_with_hours_and_minutes(self):
        n = DateTimeHelper.get_string_datetime_with_hours_and_minutes()
        
        cur_date = self.cur_date.strftime("%Y-%m-%d %H:%M")
        
        self.assertEqual(type(n), str)
        self.assertEqual(cur_date, n)
        
    def test_get_string_datetime_with_hours_and_minutes(self):
        n = DateTimeHelper.get_string_datetime_with_hours_and_minutes()
        
        cur_date = self.cur_date.strftime("%Y-%m-%d %H:%M")
        
        self.assertEqual(type(n), str)
        self.assertEqual(cur_date, n)
        
    def test_get_datetime_unix(self):
        n = DateTimeHelper.get_datetime_unix()
        
        cur_date = int(self.cur_date.timestamp())
        
        self.assertEqual(type(n), int)
        self.assertEqual(cur_date, n)
        
    