from datetime import datetime
from unittest import TestCase
from freezegun import freeze_time
from spnapiutilities.helpers.datetime_helper import DateTimeHelper


class TestDateInPeriod(TestCase):
    def setUp(self):
        self.cur_date = datetime.now()
        return super().setUp()

    def test_is_date_in_period(self):
        with freeze_time("2025-10-11"):
            assert DateTimeHelper.is_date_in_period(
                date_to_check=datetime.strptime("2025-10-11 06:35:00", "%Y-%m-%d %H:%M:%S"),
                periodes=[
                    [7,15], # shift 1
                    [22,31], # shift 3 till next day
                    [15,22], # shift 2
                ],
            ) == [22,31] # shift 3

            assert DateTimeHelper.is_date_in_period(
                date_to_check=datetime.strptime("2025-10-11 23:59:59", "%Y-%m-%d %H:%M:%S"),
                periodes=[
                    [7,15], # shift 1
                    [22,31], # shift 3 till next day
                    [15,22], # shift 2
                ],
            ) == [22,31] # shift 3


            assert DateTimeHelper.is_date_in_period(
                date_to_check=datetime.strptime("2025-10-11 13:34:59", "%Y-%m-%d %H:%M:%S"),
                periodes=[
                    [7,15], # shift 1
                    [22,31], # shift 3 till next day
                    [15,22], # shift 2
                ],
            ) == [7,15] # shift 1

            assert DateTimeHelper.is_date_in_period(
                date_to_check=datetime.strptime("2025-10-11 18:34:59", "%Y-%m-%d %H:%M:%S"),
                periodes=[
                    [7,15], # shift 1
                    [22,31], # shift 3 till next day
                    [15,22], # shift 2
                ],
            ) == [15,22] # shift 2

            assert DateTimeHelper.is_date_in_period(
                date_to_check=datetime.strptime("2025-10-11 07:00:01", "%Y-%m-%d %H:%M:%S"),
                periodes=[
                    [7,15], # shift 1
                    [22,31], # shift 3 till next day
                    [15,22], # shift 2
                ],
            ) == [7,15] # shift 1

            assert DateTimeHelper.is_date_in_period(
                date_to_check=datetime.strptime("2025-10-11 21:59:59", "%Y-%m-%d %H:%M:%S"),
                periodes=[
                    [7,15], # shift 1
                    [22,31], # shift 3 till next day
                    [15,22], # shift 2
                ],
            ) == [15,22] # shift 2

            assert DateTimeHelper.is_date_in_period(
                date_to_check=datetime.strptime("2025-10-11 21:59:59", "%Y-%m-%d %H:%M:%S"),
                periodes=[
                    [7,15], # shift 1
                    [22,31], # shift 3 till next day
                    [15,22], # shift 2
                ],
            ) == [15,22] # shift 2




            assert DateTimeHelper.is_date_in_period(
                date_to_check=datetime.strptime("2025-10-11 10:00:00", "%Y-%m-%d %H:%M:%S"),
                periodes=[
                    [-15,-10], # shift 1 -> yesterday 9-14
                    [-15,1], # shift 2
                    [1,2], # shift 3
                ],
            ) == [-15,-10] # shift 1

            assert DateTimeHelper.is_date_in_period(
                date_to_check=datetime.strptime("2025-10-11 00:05:00", "%Y-%m-%d %H:%M:%S"),
                periodes=[
                    [-15,-10], # shift 1 -> yesterday 9-14
                    [-15,1], # shift 2 -> yesterday 9 - 1 today
                    [1,2], # shift 3
                ],
            ) == [-15,1] # shift 2

            assert DateTimeHelper.is_date_in_period(
                date_to_check=datetime.strptime("2025-10-11 01:05:00", "%Y-%m-%d %H:%M:%S"),
                periodes=[
                    [-15,-10], # shift 1 -> yesterday 9-14
                    [-15,1], # shift 2 -> yesterday 9 - 1 today
                    [1,2], # shift 3
                ],
            ) == [1,2] # shift 1
       
 
