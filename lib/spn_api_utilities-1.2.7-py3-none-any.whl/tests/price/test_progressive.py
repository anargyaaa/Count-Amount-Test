"""test_class_parametrization.py"""
from datetime import datetime
from unittest import TestCase

import pytest
from freezegun import freeze_time

from spnapiutilities.builders.parking_amount_builder import ParkingAmountBuilder
from spnapiutilities.constants.price_constant import PriceType
from spnapiutilities.core.price.flat import Flat
from spnapiutilities.core.price.price_model import PriceModel
from spnapiutilities.helpers.datetime_diff_helper import DateTimeDifferenceHelper
from spnapiutilities.helpers.datetime_helper import DateTimeHelper


class TestProgressive(TestCase):
    def setUp(self):
        self.price = [
            {
                "fine": 0,
                "grace_period": 0,
                "initial_time": 1,
                "max_hour": 0,
                "min_hour": 0,
                "discount": 0,
                "max_price": 0,
                "next_price": 2000,
                "overnight_price": 0,
                "price": 4000,
                "stay_time": 0,
                "type": PriceType.PROGRESSIVE.value,
                "count_type": "INCREMENT",
                "vehicle_code": "MB1",
                "vehicle_name": "Mobil",
                "overstay_parameter": "DURATION",
                "overstay_duration": 6,
                "overstay_affected_user": "ALL",
                "overstay_product_member": [],
                "overstay_start": "",
                "overstay_end": "",
            },
            {
                "fine": 0,
                "grace_period": 0,
                "initial_time": 1,
                "max_hour": 0,
                "min_hour": 0,
                "discount": 0,
                "max_price": 0,
                "next_price": 1000,
                "overnight_price": 0,
                "price": 2000,
                "stay_time": 0,
                "type": PriceType.PROGRESSIVE.value,
                "count_type": "INCREMENT",
                "vehicle_code": "MT1",
                "vehicle_name": "Motor",
                "overstay_parameter": "DURATION",
                "overstay_duration": 0,
                "overstay_affected_user": "ALL",
                "overstay_product_member": [],
                "overstay_start": "",
                "overstay_end": "",
            },
        ]

        return super().setUp()

    def test_progressive_under_one_hour(self):
        freezer = freeze_time("2023-01-01 08:00:00")
        freezer.start()

        price = self.price[1]

        model = PriceModel()

        time_in = DateTimeHelper.get_current_millisecond()
        time_out = DateTimeHelper.get_future_return_timemillis(minute=30)

        model = PriceModel()
        model.set_id(price.get("id"))
        model.set_time_in(time_in)
        model.set_time_out(time_out)
        model.set_total_hours()
        model.set_price(price.get("price"))
        model.set_price_type(price.get("type"))
        model.set_count_type(price.get("count_type"))
        model.set_grace_period(price.get("grace_period"))
        model.set_start_price(price.get("price"))
        model.set_next_price(price.get("next_price"))
        model.set_max_price(price.get("max_price"))
        model.set_next_hours(price.get("stay_time"))
        model.set_start_hours(price.get("initial_time"))
        model.set_max_hours(price.get("max_hour"))
        model.set_overstay_price(
            price.get("overnight_price") if price.get("overnight_price") else 0
        )
        model.set_overstay_affected_user(price.get("overstay_affected_user"))
        model.set_overstay_start(
            price.get("overstay_start") if price.get("overstay_start") else None
        )
        model.set_overstay_end(
            price.get("overstay_end") if price.get("overstay_end") else None
        )
        model.set_overstay_duration(price.get("overstay_duration"))
        model.set_period_data(price.get("period_data"))

        discount = 0
        point = 0
        timezone = "Asia/Jakarta"

        model.set_discount(discount)
        model.set_point(point)
        model.set_timezone(timezone)
        model.set_price_type(price.get("type"))

        pb = ParkingAmountBuilder(model=model)
        pb = pb.build()

        assert pb.get("grace_period") == False
        assert pb.get("total_hours") == 1
        assert pb.get("total_amount") == 2000
        assert pb.get("amount") == 2000
        
    
    def test_progressive_exactly_one_hour(self):
        freezer = freeze_time("2023-01-01 08:00:00")
        freezer.start()

        price = self.price[1]

        model = PriceModel()

        time_in = DateTimeHelper.get_current_millisecond()
        time_out = DateTimeHelper.get_future_return_timemillis(minute=60)

        model = PriceModel()
        model.set_id(price.get("id"))
        model.set_time_in(time_in)
        model.set_time_out(time_out)
        model.set_total_hours()
        model.set_price(price.get("price"))
        model.set_price_type(price.get("type"))
        model.set_count_type(price.get("count_type"))
        model.set_grace_period(price.get("grace_period"))
        model.set_start_price(price.get("price"))
        model.set_next_price(price.get("next_price"))
        model.set_max_price(price.get("max_price"))
        model.set_next_hours(price.get("stay_time"))
        model.set_start_hours(price.get("initial_time"))
        model.set_max_hours(price.get("max_hour"))
        model.set_overstay_price(
            price.get("overnight_price") if price.get("overnight_price") else 0
        )
        model.set_overstay_affected_user(price.get("overstay_affected_user"))
        model.set_overstay_start(
            price.get("overstay_start") if price.get("overstay_start") else None
        )
        model.set_overstay_end(
            price.get("overstay_end") if price.get("overstay_end") else None
        )
        model.set_overstay_duration(price.get("overstay_duration"))
        model.set_period_data(price.get("period_data"))

        discount = 0
        point = 0
        timezone = "Asia/Jakarta"

        model.set_discount(discount)
        model.set_point(point)
        model.set_timezone(timezone)
        model.set_price_type(price.get("type"))

        pb = ParkingAmountBuilder(model=model)
        pb = pb.build()

        assert pb.get("grace_period") == False
        assert pb.get("total_hours") == 1
        assert pb.get("total_amount") == 2000
        assert pb.get("amount") == 2000

    def test_progressive_after_one_hour(self):
        freezer = freeze_time("2023-01-01 08:00:00")
        freezer.start()

        price = self.price[1]

        model = PriceModel()

        time_in = DateTimeHelper.get_current_millisecond()
        time_out = DateTimeHelper.get_future_return_timemillis(minute=65)

        model = PriceModel()
        model.set_id(price.get("id"))
        model.set_time_in(time_in)
        model.set_time_out(time_out)
        model.set_total_hours()
        model.set_price(price.get("price"))
        model.set_price_type(price.get("type"))
        model.set_count_type(price.get("count_type"))
        model.set_grace_period(price.get("grace_period"))
        model.set_start_price(price.get("price"))
        model.set_next_price(price.get("next_price"))
        model.set_max_price(price.get("max_price"))
        model.set_next_hours(price.get("stay_time"))
        model.set_start_hours(price.get("initial_time"))
        model.set_max_hours(price.get("max_hour"))
        model.set_overstay_price(
            price.get("overnight_price") if price.get("overnight_price") else 0
        )
        model.set_overstay_affected_user(price.get("overstay_affected_user"))
        model.set_overstay_start(
            price.get("overstay_start") if price.get("overstay_start") else None
        )
        model.set_overstay_end(
            price.get("overstay_end") if price.get("overstay_end") else None
        )
        model.set_overstay_duration(price.get("overstay_duration"))
        model.set_period_data(price.get("period_data"))

        discount = 0
        point = 0
        timezone = "Asia/Jakarta"

        model.set_discount(discount)
        model.set_point(point)
        model.set_timezone(timezone)
        model.set_price_type(price.get("type"))

        pb = ParkingAmountBuilder(model=model)
        pb = pb.build()

        assert pb.get("grace_period") == False
        assert pb.get("total_hours") == 2
        assert pb.get("total_amount") == 3000
        assert pb.get("amount") == 3000
