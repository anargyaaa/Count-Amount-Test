from spnapiutilities.helpers.datetime_helper import DateTimeHelper
from spnapiutilities.helpers.datetime_diff_helper import DateTimeDifferenceHelper
from spnapiutilities.builders.parking_amount_builder import ParkingAmountBuilder
from spnapiutilities.constants.price_constant import PriceType
from spnapiutilities.core.price.flat import Flat
from spnapiutilities.core.price.price_model import PriceModel
from datetime import datetime
from unittest import TestCase
import pytest
from freezegun import freeze_time


class TestPeriod(TestCase):
    def setUp(self):
        self.price_period = [
            {
                "fine": 0,
                "fine_type": "",
                "grace_period": 0,
                "initial_time": 5,
                "max_hour": 0,
                "min_hour": 0,
                "discount": 0,
                "max_price": 0,
                "next_price": 0,
                "overnight_price": 0,
                "price": 5,
                "stay_time": 0,
                "type": "PERIOD",
                "count_type": "INCREMENT",
                "vehicle_code": "MT1",
                "vehicle_name": "Motor",
                "overstay_parameter": None,
                "overstay_duration": None,
                "overstay_affected_user": None,
                "overstay_product_member": [],
                "overstay_start": None,
                "overstay_end": None,
                "period_data": [
                    {
                        "end": 10,
                        "price": 10000,
                        "start": 6
                    },
                    {
                        "end": 15,
                        "price": 30000,
                        "start": 10
                    },
                    {
                        "end": 18,
                        "price": 50000,
                        "start": 15
                    },
                    {
                        "end": 30,
                        "price": 60000,
                        "start": 18,
                    }
                ]
            }
        ]

        return super().setUp()

    def setup_price_model(self,
                          hours_setup: int = 0, minutes_setup: int = 0,
                          seconds_setup: int = 0, change_init_time: int = None):
        price = self.price_period[0]
        model = PriceModel()
        if change_init_time != None:
            price['initial_time'] = change_init_time

        time_in = DateTimeHelper.get_current_millisecond()
        time_out = DateTimeHelper.get_future_from_timemillis_detail(
            time_in, hours=hours_setup, minutes=minutes_setup, seconds=seconds_setup)

        model.set_id(price.get("id"))
        model.set_time_in(time_in)
        model.set_time_out(time_out)
        model.set_total_hours()
        model.set_price(price.get("price"))
        model.set_price_type(price.get('type'))
        model.set_count_type(price.get('count_type'))
        model.set_grace_period(price.get("grace_period"))
        model.set_start_price(price.get('price'))
        model.set_next_price(price.get('next_price'))
        model.set_max_price(price.get('max_price'))
        model.set_next_hours(price.get('stay_time'))
        model.set_start_hours(price.get("initial_time"))
        model.set_max_hours(price.get("max_hour"))
        model.set_overstay_price(
            price.get("overnight_price") if price.get('overnight_price') else 0)
        model.set_overstay_affected_user(price.get("overstay_affected_user"))
        model.set_overstay_start(
            price.get("overstay_start") if price.get("overstay_start") else None)
        model.set_overstay_end(price.get("overstay_end")
                               if price.get("overstay_end") else None)
        model.set_overstay_duration(price.get("overstay_duration"))
        model.set_period_data(price.get("period_data"))

        discount = 0
        point = 0
        timezone = None

        model.set_discount(discount)
        model.set_point(point)
        model.set_timezone(timezone)
        model.set_price_type(price.get('type'))

        return model

    def test_period_1(self):
        freezer = freeze_time("2023-01-01 06:00:00")
        freezer.start()

        model = self.setup_price_model(hours_setup=2, minutes_setup=30)

        pb = ParkingAmountBuilder(model=model)
        pb = pb.build()

        assert pb.get('grace_period') == False
        assert pb.get('total_hours') == 3
        assert pb.get('total_amount') == 5
        assert pb.get('amount') == 5
        assert pb.get('overnight_price') == 0

    def test_period_2(self):
        freezer = freeze_time("2023-01-01 14:00:00")
        freezer.start()

        model = self.setup_price_model(hours_setup=2, minutes_setup=20)

        pb = ParkingAmountBuilder(model=model)
        pb = pb.build()

        assert pb.get('grace_period') == False
        assert pb.get('total_hours') == 3
        assert pb.get('total_amount') == 5
        assert pb.get('amount') == 5
        assert pb.get('overnight_price') == 0

    def test_period_3(self):
        freezer = freeze_time("2023-01-01 12:35:00")
        freezer.start()

        model = self.setup_price_model(hours_setup=3, minutes_setup=5)

        pb = ParkingAmountBuilder(model=model)
        pb = pb.build()

        assert pb.get('grace_period') == False
        assert pb.get('total_hours') == 4
        assert pb.get('total_amount') == 5
        assert pb.get('amount') == 5
        assert pb.get('overnight_price') == 0

    def test_period_4(self):
        freezer = freeze_time("2023-01-01 16:10:00")
        freezer.start()

        model = self.setup_price_model(hours_setup=1, minutes_setup=44)

        pb = ParkingAmountBuilder(model=model)
        pb = pb.build()

        assert pb.get('grace_period') == False
        assert pb.get('total_hours') == 2
        assert pb.get('total_amount') == 5
        assert pb.get('amount') == 5
        assert pb.get('overnight_price') == 0

    def test_period_5(self):
        freezer = freeze_time("2023-01-01 06:00:00")
        freezer.start()

        model = self.setup_price_model(hours_setup=3, minutes_setup=59)

        pb = ParkingAmountBuilder(model=model)
        pb = pb.build()

        assert pb.get('grace_period') == False
        assert pb.get('total_hours') == 4
        assert pb.get('total_amount') == 5
        assert pb.get('amount') == 5
        assert pb.get('overnight_price') == 0

    def test_period_6(self):
        freezer = freeze_time("2023-01-01 06:00:00")
        freezer.start()

        model = self.setup_price_model(hours_setup=4)

        pb = ParkingAmountBuilder(model=model)
        pb = pb.build()

        assert pb.get('grace_period') == False
        assert pb.get('total_hours') == 4
        assert pb.get('total_amount') == 5
        assert pb.get('amount') == 5
        assert pb.get('overnight_price') == 0

    def test_period_7(self):
        freezer = freeze_time("2023-01-01 06:00:00")
        freezer.start()

        model = self.setup_price_model(hours_setup=4, seconds_setup=1)

        pb = ParkingAmountBuilder(model=model)
        pb = pb.build()

        assert pb.get('grace_period') == False
        assert pb.get('total_hours') == 5
        assert pb.get('total_amount') == 5
        assert pb.get('amount') == 5
        assert pb.get('overnight_price') == 0

    def test_period_8(self):
        freezer = freeze_time("2023-01-01 06:00:00", tz_offset=0)
        freezer.start()

        model = self.setup_price_model(
            hours_setup=8, minutes_setup=59, seconds_setup=59)

        pb = ParkingAmountBuilder(model=model)
        pb = pb.build()

        assert pb.get('grace_period') == False
        assert pb.get('total_hours') == 9
        assert pb.get('total_amount') == 30000
        assert pb.get('amount') == 30000
        assert pb.get('overnight_price') == 0

    def test_period_9(self):
        freezer = freeze_time("2023-01-01 06:00:00", tz_offset=0)
        freezer.start()

        model = self.setup_price_model(hours_setup=9)

        pb = ParkingAmountBuilder(model=model)
        pb = pb.build()

        assert pb.get('grace_period') == False
        assert pb.get('total_hours') == 9
        assert pb.get('total_amount') == 50000
        assert pb.get('amount') == 50000
        assert pb.get('overnight_price') == 0

    def test_period_10(self):
        freezer = freeze_time("2023-01-01 06:00:00", tz_offset=0)
        freezer.start()

        model = self.setup_price_model(hours_setup=9, seconds_setup=1)

        pb = ParkingAmountBuilder(model=model)
        pb = pb.build()

        assert pb.get('grace_period') == False
        assert pb.get('total_hours') == 10
        assert pb.get('total_amount') == 50000
        assert pb.get('amount') == 50000
        assert pb.get('overnight_price') == 0

    def test_period_11(self):
        freezer = freeze_time("2023-01-01 06:00:00", tz_offset=0)
        freezer.start()

        model = self.setup_price_model(
            hours_setup=11, minutes_setup=59, seconds_setup=59)

        pb = ParkingAmountBuilder(model=model)
        pb = pb.build()

        assert pb.get('grace_period') == False
        assert pb.get('total_hours') == 12
        assert pb.get('total_amount') == 50000
        assert pb.get('amount') == 50000
        assert pb.get('overnight_price') == 0

    def test_period_12(self):
        freezer = freeze_time("2023-01-01 06:00:00", tz_offset=0)
        freezer.start()

        model = self.setup_price_model(hours_setup=12)

        pb = ParkingAmountBuilder(model=model)
        pb = pb.build()

        assert pb.get('grace_period') == False
        assert pb.get('total_hours') == 12
        assert pb.get('total_amount') == 60000
        assert pb.get('amount') == 60000
        assert pb.get('overnight_price') == 0

    def test_period_13(self):
        freezer = freeze_time("2023-01-01 06:00:00", tz_offset=0)
        freezer.start()

        model = self.setup_price_model(hours_setup=12, seconds_setup=1)

        pb = ParkingAmountBuilder(model=model)
        pb = pb.build()

        assert pb.get('grace_period') == False
        assert pb.get('total_hours') == 13
        assert pb.get('total_amount') == 60000
        assert pb.get('amount') == 60000
        assert pb.get('overnight_price') == 0

    def test_period_14(self):
        freezer = freeze_time("2023-01-01 06:00:00", tz_offset=0)
        freezer.start()

        model = self.setup_price_model(hours_setup=22, minutes_setup=30)

        pb = ParkingAmountBuilder(model=model)
        pb = pb.build()

        assert pb.get('grace_period') == False
        assert pb.get('total_hours') == 23
        assert pb.get('total_amount') == 60000
        assert pb.get('amount') == 60000
        assert pb.get('overnight_price') == 0

    def test_period_15(self):
        freezer = freeze_time("2023-01-01 06:00:00", tz_offset=0)
        freezer.start()

        model = self.setup_price_model(
            hours_setup=23, minutes_setup=59, seconds_setup=59)

        pb = ParkingAmountBuilder(model=model)
        pb = pb.build()

        assert pb.get('grace_period') == False
        assert pb.get('total_hours') == 24
        assert pb.get('total_amount') == 60000
        assert pb.get('amount') == 60000
        assert pb.get('overnight_price') == 0

    def test_period_16(self):
        freezer = freeze_time("2023-01-01 06:00:00", tz_offset=0)
        freezer.start()

        model = self.setup_price_model(hours_setup=24)

        pb = ParkingAmountBuilder(model=model)
        pb = pb.build()

        assert pb.get('grace_period') == False
        assert pb.get('total_hours') == 24
        assert pb.get('total_amount') == 70000
        assert pb.get('amount') == 70000
        assert pb.get('overnight_price') == 0

    def test_period_17(self):
        freezer = freeze_time("2023-01-01 06:00:00", tz_offset=0)
        freezer.start()

        model = self.setup_price_model(hours_setup=24, seconds_setup=1)

        pb = ParkingAmountBuilder(model=model)
        pb = pb.build()

        assert pb.get('grace_period') == False
        assert pb.get('total_hours') == 25
        assert pb.get('total_amount') == 70000
        assert pb.get('amount') == 70000
        assert pb.get('overnight_price') == 0

    def test_period_18(self):
        freezer = freeze_time("2023-01-01 06:00:00", tz_offset=0)
        freezer.start()

        model = self.setup_price_model(
            hours_setup=32, minutes_setup=59, seconds_setup=59)

        pb = ParkingAmountBuilder(model=model)
        pb = pb.build()

        assert pb.get('grace_period') == False
        assert pb.get('total_hours') == 33
        assert pb.get('total_amount') == 90000
        assert pb.get('amount') == 90000
        assert pb.get('overnight_price') == 0

    def test_period_19(self):
        freezer = freeze_time("2023-01-01 06:00:00", tz_offset=0)
        freezer.start()

        model = self.setup_price_model(hours_setup=33)

        pb = ParkingAmountBuilder(model=model)
        pb = pb.build()

        assert pb.get('grace_period') == False
        assert pb.get('total_hours') == 33
        assert pb.get('total_amount') == 110000
        assert pb.get('amount') == 110000
        assert pb.get('overnight_price') == 0

    def test_period_20(self):
        freezer = freeze_time("2023-01-01 06:00:00", tz_offset=0)
        freezer.start()

        model = self.setup_price_model(hours_setup=33, seconds_setup=1)

        pb = ParkingAmountBuilder(model=model)
        pb = pb.build()

        assert pb.get('grace_period') == False
        assert pb.get('total_hours') == 34
        assert pb.get('total_amount') == 110000
        assert pb.get('amount') == 110000
        assert pb.get('overnight_price') == 0

    def test_period_21(self):
        freezer = freeze_time("2023-01-01 06:00:00", tz_offset=0)
        freezer.start()

        model = self.setup_price_model(
            hours_setup=33, minutes_setup=59, seconds_setup=59)

        pb = ParkingAmountBuilder(model=model)
        pb = pb.build()

        assert pb.get('grace_period') == False
        assert pb.get('total_hours') == 34
        assert pb.get('total_amount') == 110000
        assert pb.get('amount') == 110000
        assert pb.get('overnight_price') == 0

    def test_period_22(self):
        freezer = freeze_time("2023-01-01 06:00:00", tz_offset=0)
        freezer.start()

        model = self.setup_price_model(hours_setup=36)

        pb = ParkingAmountBuilder(model=model)
        pb = pb.build()

        assert pb.get('grace_period') == False
        assert pb.get('total_hours') == 36
        assert pb.get('total_amount') == 120000
        assert pb.get('amount') == 120000
        assert pb.get('overnight_price') == 0

    def test_period_23(self):
        freezer = freeze_time("2023-01-01 06:00:00", tz_offset=0)
        freezer.start()

        model = self.setup_price_model(hours_setup=36, seconds_setup=1)

        pb = ParkingAmountBuilder(model=model)
        pb = pb.build()

        assert pb.get('grace_period') == False
        assert pb.get('total_hours') == 37
        assert pb.get('total_amount') == 120000
        assert pb.get('amount') == 120000
        assert pb.get('overnight_price') == 0

    def test_period_24(self):
        freezer = freeze_time("2023-01-01 06:00:00", tz_offset=0)
        freezer.start()

        model = self.setup_price_model(
            hours_setup=47, minutes_setup=59, seconds_setup=59)

        pb = ParkingAmountBuilder(model=model)
        pb = pb.build()

        assert pb.get('grace_period') == False
        assert pb.get('total_hours') == 48
        assert pb.get('total_amount') == 120000
        assert pb.get('amount') == 120000
        assert pb.get('overnight_price') == 0

    def test_period_25(self):
        freezer = freeze_time("2023-01-01 06:00:00", tz_offset=0)
        freezer.start()

        model = self.setup_price_model(hours_setup=48)

        pb = ParkingAmountBuilder(model=model)
        pb = pb.build()

        assert pb.get('grace_period') == False
        assert pb.get('total_hours') == 48
        assert pb.get('total_amount') == 130000
        assert pb.get('amount') == 130000
        assert pb.get('overnight_price') == 0

    def test_period_26(self):
        freezer = freeze_time("2023-01-01 06:00:00", tz_offset=0)
        freezer.start()

        model = self.setup_price_model(hours_setup=48, seconds_setup=1)

        pb = ParkingAmountBuilder(model=model)
        pb = pb.build()

        assert pb.get('grace_period') == False
        assert pb.get('total_hours') == 49
        assert pb.get('total_amount') == 130000
        assert pb.get('amount') == 130000
        assert pb.get('overnight_price') == 0

    def test_period_27(self):
        freezer = freeze_time("2023-01-01 06:00:00", tz_offset=0)
        freezer.start()

        model = self.setup_price_model(
            hours_setup=71, minutes_setup=59, seconds_setup=59)

        pb = ParkingAmountBuilder(model=model)
        pb = pb.build()

        assert pb.get('grace_period') == False
        assert pb.get('total_hours') == 72
        assert pb.get('total_amount') == 180000
        assert pb.get('amount') == 180000
        assert pb.get('overnight_price') == 0

    def test_period_28(self):
        freezer = freeze_time("2023-01-01 06:00:00", tz_offset=0)
        freezer.start()

        model = self.setup_price_model(hours_setup=72)

        pb = ParkingAmountBuilder(model=model)
        pb = pb.build()

        assert pb.get('grace_period') == False
        assert pb.get('total_hours') == 72
        assert pb.get('total_amount') == 190000
        assert pb.get('amount') == 190000
        assert pb.get('overnight_price') == 0

    def test_period_29(self):
        freezer = freeze_time("2023-01-01 06:00:00")
        freezer.start()

        model = self.setup_price_model(
            change_init_time=1, hours_setup=2, minutes_setup=30)

        pb = ParkingAmountBuilder(model=model)
        pb = pb.build()

        assert pb.get('grace_period') == False
        assert pb.get('total_hours') == 3
        assert pb.get('total_amount') == 10000
        assert pb.get('amount') == 10000
        assert pb.get('overnight_price') == 0

    def test_period_30(self):
        freezer = freeze_time("2023-01-01 06:00:00")
        freezer.start()

        model = self.setup_price_model(change_init_time=3, hours_setup=3)

        pb = ParkingAmountBuilder(model=model)
        pb = pb.build()

        assert pb.get('grace_period') == False
        assert pb.get('total_hours') == 3
        assert pb.get('total_amount') == 10000
        assert pb.get('amount') == 10000
        assert pb.get('overnight_price') == 0

    def test_period_31(self):
        freezer = freeze_time("2023-01-01 06:00:00")
        freezer.start()

        model = self.setup_price_model(
            change_init_time=3, hours_setup=3, seconds_setup=1)

        pb = ParkingAmountBuilder(model=model)
        pb = pb.build()

        assert pb.get('grace_period') == False
        assert pb.get('total_hours') == 4
        assert pb.get('total_amount') == 10000
        assert pb.get('amount') == 10000
        assert pb.get('overnight_price') == 0

    def test_period_32(self):
        freezer = freeze_time("2023-01-01 06:00:00")
        freezer.start()

        model = self.setup_price_model(change_init_time=0, seconds_setup=10)

        pb = ParkingAmountBuilder(model=model)
        pb = pb.build()

        assert pb.get('grace_period') == False
        assert pb.get('total_hours') == 1
        assert pb.get('total_amount') == 10000
        assert pb.get('amount') == 10000
        assert pb.get('overnight_price') == 0

    def test_period_33(self):
        freezer = freeze_time("2023-01-01 02:51:00")
        freezer.start()

        model = self.setup_price_model(hours_setup=7, minutes_setup=21)

        pb = ParkingAmountBuilder(model=model)
        pb = pb.build()

        assert pb.get('grace_period') == False
        assert pb.get('total_hours') == 8
        assert pb.get('total_amount') == 90000
        assert pb.get('amount') == 90000
        assert pb.get('overnight_price') == 0

    def test_period_34(self):
        freezer = freeze_time("2023-01-01 01:29:00")
        freezer.start()

        model = self.setup_price_model(
            hours_setup=11, minutes_setup=21, change_init_time=1)

        pb = ParkingAmountBuilder(model=model)
        pb = pb.build()

        assert pb.get('grace_period') == False
        assert pb.get('total_hours') == 12
        assert pb.get('total_amount') == 90000
        assert pb.get('amount') == 90000
        assert pb.get('overnight_price') == 0

    def test_period_35(self):
        freezer = freeze_time("2023-01-01 05:59:59")
        freezer.start()

        model = self.setup_price_model(
            hours_setup=2, minutes_setup=19, change_init_time=1)

        pb = ParkingAmountBuilder(model=model)
        pb = pb.build()

        assert pb.get('grace_period') == False
        assert pb.get('total_hours') == 3
        assert pb.get('total_amount') == 70000
        assert pb.get('amount') == 70000
        assert pb.get('overnight_price') == 0

    def test_period_36(self):
        freezer = freeze_time("2023-01-01 18:27")
        freezer.start()

        model = self.setup_price_model(minutes_setup=1, change_init_time=0)

        pb = ParkingAmountBuilder(model=model)
        pb = pb.build()

        assert pb.get('grace_period') == False
        assert pb.get('total_hours') == 1
        assert pb.get('total_amount') == 60000
        assert pb.get('amount') == 60000
        assert pb.get('overnight_price') == 0

    def test_period_37(self):
        freezer = freeze_time("2023-01-01 5:30")
        freezer.start()

        model = self.setup_price_model(hours_setup=1, change_init_time=0)

        pb = ParkingAmountBuilder(model=model)
        pb = pb.build()

        assert pb.get('grace_period') == False
        assert pb.get('total_hours') == 1
        assert pb.get('total_amount') == 70000
        assert pb.get('amount') == 70000
        assert pb.get('overnight_price') == 0
