"""test_class_parametrization.py"""
from datetime import datetime
from unittest import TestCase

import pytest
from freezegun import freeze_time

from spnapiutilities.builders.parking_amount_builder import ParkingAmountBuilder
from spnapiutilities.constants.price_constant import PriceType
from spnapiutilities.core.price.flat import Flat
from spnapiutilities.core.price.price_model import PriceModel
from spnapiutilities.helpers.datetime_diff_helper import DateTimeDifferenceHelper
from spnapiutilities.helpers.datetime_helper import DateTimeHelper


class TestLimitedProgressiveRange(TestCase):
    def setUp(self):
        self.price = [
            {
                "fine": 0,
                "grace_period": 0,
                "initial_time": 12,
                "max_hour": 24,
                "min_hour": 0,
                "discount": 0,
                "max_price": 0,
                "next_price": 3000,
                "overnight_price": 0,
                "price": 8000,
                "stay_time": 12,
                "type": PriceType.LIMITED_PROGRESSIVE.value,
                "count_type": PriceType.COUNT_TYPE_RANGE.value,
                "vehicle_code": "MT2",
                "vehicle_name": "Motor Besar",
                "overstay_parameter": "DURATION",
                "overstay_duration": 0,
                "overstay_affected_user": "ALL",
                "overstay_product_member": [],
                "overstay_start": "",
                "overstay_end": "",
            },
            {
                "fine": 0,
                "grace_period": 0,
                "initial_time": 12,
                "max_hour": 24,
                "min_hour": 0,
                "discount": 0,
                "max_price": 0,
                "next_price": 3000,
                "overnight_price": 0,
                "price": 7000,
                "stay_time": 12,
                "type": PriceType.LIMITED_PROGRESSIVE.value,
                "count_type": PriceType.COUNT_TYPE_RANGE.value,
                "vehicle_code": "MT1",
                "vehicle_name": "Motor Kecil",
                "overstay_parameter": "DURATION",
                "overstay_duration": 0,
                "overstay_affected_user": "ALL",
                "overstay_product_member": [],
                "overstay_start": "",
                "overstay_end": "",
            },
        ]

        return super().setUp()

    def test_limited_progressive_range_thirty_minutes(self):
        freezer = freeze_time("2023-01-01 08:00:00")
        freezer.start()

        price = self.price[1]

        time_in = DateTimeHelper.get_current_millisecond()
        time_out = DateTimeHelper.get_future_return_timemillis(minute=30)

        model = PriceModel()
        model.set_id(price.get("id"))
        model.set_time_in(time_in)
        model.set_time_out(time_out)
        model.set_total_hours()
        model.set_price(price.get("price"))
        model.set_price_type(price.get("type"))
        model.set_count_type(price.get("count_type"))
        model.set_grace_period(price.get("grace_period"))
        model.set_start_price(price.get("price"))
        model.set_next_price(price.get("next_price"))
        model.set_max_price(price.get("max_price"))
        model.set_next_hours(price.get("stay_time"))
        model.set_start_hours(price.get("initial_time"))
        model.set_max_hours(price.get("max_hour"))
        model.set_overstay_price(
            price.get("overnight_price") if price.get("overnight_price") else 0
        )
        model.set_overstay_affected_user(price.get("overstay_affected_user"))
        model.set_overstay_start(
            price.get("overstay_start") if price.get("overstay_start") else None
        )
        model.set_overstay_end(
            price.get("overstay_end") if price.get("overstay_end") else None
        )
        model.set_overstay_duration(price.get("overstay_duration"))
        model.set_period_data(price.get("period_data"))

        discount = 0
        point = 0
        timezone = "Asia/Jakarta"

        model.set_discount(discount)
        model.set_point(point)
        model.set_timezone(timezone)
        model.set_price_type(price.get("type"))

        pb = ParkingAmountBuilder(model=model)
        pb = pb.build()

        assert pb.get("grace_period") == False
        assert pb.get("total_hours") == 1
        assert pb.get("total_amount") == 7000
        assert pb.get("amount") == 7000

    def test_limited_progressive_range_one_hour(self):
        freezer = freeze_time("2023-01-01 08:00:00")
        freezer.start()

        price = self.price[1]

        time_in = DateTimeHelper.get_current_millisecond()
        time_out = DateTimeHelper.get_future_return_timemillis(minute=60)

        model = PriceModel()
        model.set_id(price.get("id"))
        model.set_time_in(time_in)
        model.set_time_out(time_out)
        model.set_total_hours()
        model.set_price(price.get("price"))
        model.set_price_type(price.get("type"))
        model.set_count_type(price.get("count_type"))
        model.set_grace_period(price.get("grace_period"))
        model.set_start_price(price.get("price"))
        model.set_next_price(price.get("next_price"))
        model.set_max_price(price.get("max_price"))
        model.set_next_hours(price.get("stay_time"))
        model.set_start_hours(price.get("initial_time"))
        model.set_max_hours(price.get("max_hour"))
        model.set_overstay_price(
            price.get("overnight_price") if price.get("overnight_price") else 0
        )
        model.set_overstay_affected_user(price.get("overstay_affected_user"))
        model.set_overstay_start(
            price.get("overstay_start") if price.get("overstay_start") else None
        )
        model.set_overstay_end(
            price.get("overstay_end") if price.get("overstay_end") else None
        )
        model.set_overstay_duration(price.get("overstay_duration"))
        model.set_period_data(price.get("period_data"))

        discount = 0
        point = 0
        timezone = "Asia/Jakarta"

        model.set_discount(discount)
        model.set_point(point)
        model.set_timezone(timezone)
        model.set_price_type(price.get("type"))

        pb = ParkingAmountBuilder(model=model)
        pb = pb.build()

        assert pb.get("grace_period") == False
        assert pb.get("total_hours") == 1
        assert pb.get("total_amount") == 7000
        assert pb.get("amount") == 7000

    def test_limited_progressive_range_under_start_time(self):
        freezer = freeze_time("2023-01-01 08:00:00")
        freezer.start()

        price = self.price[1]

        time_in = DateTimeHelper.get_current_millisecond()
        time_out = DateTimeHelper.get_future_return_timemillis(hour=11, minute=50)

        model = PriceModel()
        model.set_id(price.get("id"))
        model.set_time_in(time_in)
        model.set_time_out(time_out)
        model.set_total_hours()
        model.set_price(price.get("price"))
        model.set_price_type(price.get("type"))
        model.set_count_type(price.get("count_type"))
        model.set_grace_period(price.get("grace_period"))
        model.set_start_price(price.get("price"))
        model.set_next_price(price.get("next_price"))
        model.set_max_price(price.get("max_price"))
        model.set_next_hours(price.get("stay_time"))
        model.set_start_hours(price.get("initial_time"))
        model.set_max_hours(price.get("max_hour"))
        model.set_overstay_price(
            price.get("overnight_price") if price.get("overnight_price") else 0
        )
        model.set_overstay_affected_user(price.get("overstay_affected_user"))
        model.set_overstay_start(
            price.get("overstay_start") if price.get("overstay_start") else None
        )
        model.set_overstay_end(
            price.get("overstay_end") if price.get("overstay_end") else None
        )
        model.set_overstay_duration(price.get("overstay_duration"))
        model.set_period_data(price.get("period_data"))

        discount = 0
        point = 0
        timezone = "Asia/Jakarta"

        model.set_discount(discount)
        model.set_point(point)
        model.set_timezone(timezone)
        model.set_price_type(price.get("type"))

        pb = ParkingAmountBuilder(model=model)
        pb = pb.build()

        assert pb.get("grace_period") == False
        assert pb.get("total_hours") == 12
        assert pb.get("total_amount") == 7000
        assert pb.get("amount") == 7000

    def test_limited_progressive_range_one_more_minute_after_start_time(self):
        freezer = freeze_time("2023-01-01 08:00:00")
        freezer.start()

        price = self.price[1]

        time_in = DateTimeHelper.get_current_millisecond()
        time_out = DateTimeHelper.get_future_return_timemillis(hour=12, minute=1)

        model = PriceModel()
        model.set_id(price.get("id"))
        model.set_time_in(time_in)
        model.set_time_out(time_out)
        model.set_total_hours()
        model.set_price(price.get("price"))
        model.set_price_type(price.get("type"))
        model.set_count_type(price.get("count_type"))
        model.set_grace_period(price.get("grace_period"))
        model.set_start_price(price.get("price"))
        model.set_next_price(price.get("next_price"))
        model.set_max_price(price.get("max_price"))
        model.set_next_hours(price.get("stay_time"))
        model.set_start_hours(price.get("initial_time"))
        model.set_max_hours(price.get("max_hour"))
        model.set_overstay_price(
            price.get("overnight_price") if price.get("overnight_price") else 0
        )
        model.set_overstay_affected_user(price.get("overstay_affected_user"))
        model.set_overstay_start(
            price.get("overstay_start") if price.get("overstay_start") else None
        )
        model.set_overstay_end(
            price.get("overstay_end") if price.get("overstay_end") else None
        )
        model.set_overstay_duration(price.get("overstay_duration"))
        model.set_period_data(price.get("period_data"))

        discount = 0
        point = 0
        timezone = "Asia/Jakarta"

        model.set_discount(discount)
        model.set_point(point)
        model.set_timezone(timezone)
        model.set_price_type(price.get("type"))

        pb = ParkingAmountBuilder(model=model)
        pb = pb.build()

        assert pb.get("grace_period") == False
        assert pb.get("total_hours") == 13
        assert pb.get("total_amount") == 10000
        assert pb.get("amount") == 10000

    def test_limited_progressive_range_one_more_minute_after_start_time(self):
        freezer = freeze_time("2023-01-01 08:00:00")
        freezer.start()

        price = self.price[1]

        time_in = DateTimeHelper.get_current_millisecond()
        time_out = DateTimeHelper.get_future_return_timemillis(hour=12, minute=1)

        model = PriceModel()
        model.set_id(price.get("id"))
        model.set_time_in(time_in)
        model.set_time_out(time_out)
        model.set_total_hours()
        model.set_price(price.get("price"))
        model.set_price_type(price.get("type"))
        model.set_count_type(price.get("count_type"))
        model.set_grace_period(price.get("grace_period"))
        model.set_start_price(price.get("price"))
        model.set_next_price(price.get("next_price"))
        model.set_max_price(price.get("max_price"))
        model.set_next_hours(price.get("stay_time"))
        model.set_start_hours(price.get("initial_time"))
        model.set_max_hours(price.get("max_hour"))
        model.set_overstay_price(
            price.get("overnight_price") if price.get("overnight_price") else 0
        )
        model.set_overstay_affected_user(price.get("overstay_affected_user"))
        model.set_overstay_start(
            price.get("overstay_start") if price.get("overstay_start") else None
        )
        model.set_overstay_end(
            price.get("overstay_end") if price.get("overstay_end") else None
        )
        model.set_overstay_duration(price.get("overstay_duration"))
        model.set_period_data(price.get("period_data"))

        discount = 0
        point = 0
        timezone = "Asia/Jakarta"

        model.set_discount(discount)
        model.set_point(point)
        model.set_timezone(timezone)
        model.set_price_type(price.get("type"))

        pb = ParkingAmountBuilder(model=model)
        pb = pb.build()

        assert pb.get("grace_period") == False
        assert pb.get("total_hours") == 13
        assert pb.get("total_amount") == 10000
        assert pb.get("amount") == 10000

    def test_limited_progressive_less_than_one_minute_to_next_time(self):
        freezer = freeze_time("2023-01-01 08:00:00")
        freezer.start()

        price = self.price[1]

        time_in = DateTimeHelper.get_current_millisecond()
        time_out = DateTimeHelper.get_future_return_timemillis(hour=23, minute=59)

        model = PriceModel()
        model.set_id(price.get("id"))
        model.set_time_in(time_in)
        model.set_time_out(time_out)
        model.set_total_hours()
        model.set_price(price.get("price"))
        model.set_price_type(price.get("type"))
        model.set_count_type(price.get("count_type"))
        model.set_grace_period(price.get("grace_period"))
        model.set_start_price(price.get("price"))
        model.set_next_price(price.get("next_price"))
        model.set_max_price(price.get("max_price"))
        model.set_next_hours(price.get("stay_time"))
        model.set_start_hours(price.get("initial_time"))
        model.set_max_hours(price.get("max_hour"))
        model.set_overstay_price(
            price.get("overnight_price") if price.get("overnight_price") else 0
        )
        model.set_overstay_affected_user(price.get("overstay_affected_user"))
        model.set_overstay_start(
            price.get("overstay_start") if price.get("overstay_start") else None
        )
        model.set_overstay_end(
            price.get("overstay_end") if price.get("overstay_end") else None
        )
        model.set_overstay_duration(price.get("overstay_duration"))
        model.set_period_data(price.get("period_data"))

        discount = 0
        point = 0
        timezone = "Asia/Jakarta"

        model.set_discount(discount)
        model.set_point(point)
        model.set_timezone(timezone)
        model.set_price_type(price.get("type"))

        pb = ParkingAmountBuilder(model=model)
        pb = pb.build()

        assert pb.get("grace_period") == False
        assert pb.get("total_hours") == 24
        assert pb.get("total_amount") == 10000
        assert pb.get("amount") == 10000

    def test_limited_progressive_less_than_one_minute_to_next_time(self):
        freezer = freeze_time("2023-01-01 08:00:00")
        freezer.start()

        price = self.price[1]

        time_in = DateTimeHelper.get_current_millisecond()
        time_out = DateTimeHelper.get_future_return_timemillis(hour=23, minute=59)

        model = PriceModel()
        model.set_id(price.get("id"))
        model.set_time_in(time_in)
        model.set_time_out(time_out)
        model.set_total_hours()
        model.set_price(price.get("price"))
        model.set_price_type(price.get("type"))
        model.set_count_type(price.get("count_type"))
        model.set_grace_period(price.get("grace_period"))
        model.set_start_price(price.get("price"))
        model.set_next_price(price.get("next_price"))
        model.set_max_price(price.get("max_price"))
        model.set_next_hours(price.get("stay_time"))
        model.set_start_hours(price.get("initial_time"))
        model.set_max_hours(price.get("max_hour"))
        model.set_overstay_price(
            price.get("overnight_price") if price.get("overnight_price") else 0
        )
        model.set_overstay_affected_user(price.get("overstay_affected_user"))
        model.set_overstay_start(
            price.get("overstay_start") if price.get("overstay_start") else None
        )
        model.set_overstay_end(
            price.get("overstay_end") if price.get("overstay_end") else None
        )
        model.set_overstay_duration(price.get("overstay_duration"))
        model.set_period_data(price.get("period_data"))

        discount = 0
        point = 0
        timezone = "Asia/Jakarta"

        model.set_discount(discount)
        model.set_point(point)
        model.set_timezone(timezone)
        model.set_price_type(price.get("type"))

        pb = ParkingAmountBuilder(model=model)
        pb = pb.build()

        assert pb.get("grace_period") == False
        assert pb.get("total_hours") == 24
        assert pb.get("total_amount") == 10000
        assert pb.get("amount") == 10000

    def test_limited_progressive_after_max_hours(self):
        freezer = freeze_time("2023-01-01 08:00:00")
        freezer.start()

        price = self.price[1]

        time_in = DateTimeHelper.get_current_millisecond()
        time_out = DateTimeHelper.get_future_return_timemillis(hour=18, minute=32)

        model = PriceModel()
        model.set_id(price.get("id"))
        model.set_time_in(time_in)
        model.set_time_out(time_out)
        model.set_total_hours()
        model.set_price(price.get("price"))
        model.set_price_type(price.get("type"))
        model.set_count_type(price.get("count_type"))
        model.set_grace_period(price.get("grace_period"))
        model.set_start_price(price.get("price"))
        model.set_next_price(price.get("next_price"))
        model.set_max_price(5000)
        model.set_next_hours(price.get("stay_time"))
        model.set_start_hours(price.get("initial_time"))
        model.set_max_hours(price.get("max_hour"))
        model.set_overstay_price(
            price.get("overnight_price") if price.get("overnight_price") else 0
        )
        model.set_overstay_affected_user(price.get("overstay_affected_user"))
        model.set_overstay_start(
            price.get("overstay_start") if price.get("overstay_start") else None
        )
        model.set_overstay_end(
            price.get("overstay_end") if price.get("overstay_end") else None
        )
        model.set_overstay_duration(price.get("overstay_duration"))
        model.set_period_data(price.get("period_data"))

        discount = 0
        point = 0
        timezone = "Asia/Jakarta"

        model.set_discount(discount)
        model.set_point(point)
        model.set_timezone(timezone)
        model.set_price_type(price.get("type"))

        pb = ParkingAmountBuilder(model=model)
        pb = pb.build()

        assert pb.get("grace_period") == False
        assert pb.get("total_hours") == 19
        assert pb.get("total_amount") == 5000
        assert pb.get("amount") == 5000

    def test_limited_progressive_after_37_hours(self):
        freezer = freeze_time("2023-01-01 08:00:00")
        freezer.start()

        price = self.price[1]

        time_in = DateTimeHelper.get_current_millisecond()
        time_out = DateTimeHelper.get_future_return_timemillis(hour=37)

        model = PriceModel()
        model.set_id(price.get("id"))
        model.set_time_in(time_in)
        model.set_time_out(time_out)
        model.set_total_hours()
        model.set_price(price.get("price"))
        model.set_price_type(price.get("type"))
        model.set_count_type(price.get("count_type"))
        model.set_grace_period(price.get("grace_period"))
        model.set_start_price(price.get("price"))
        model.set_next_price(price.get("next_price"))
        model.set_max_price(price.get("max_price"))
        model.set_next_hours(price.get("stay_time"))
        model.set_start_hours(price.get("initial_time"))
        model.set_max_hours(price.get("max_hour"))
        model.set_overstay_price(
            price.get("overnight_price") if price.get("overnight_price") else 0
        )
        model.set_overstay_affected_user(price.get("overstay_affected_user"))
        model.set_overstay_start(
            price.get("overstay_start") if price.get("overstay_start") else None
        )
        model.set_overstay_end(
            price.get("overstay_end") if price.get("overstay_end") else None
        )
        model.set_overstay_duration(price.get("overstay_duration"))
        model.set_period_data(price.get("period_data"))

        discount = 0
        point = 0
        timezone = "Asia/Jakarta"

        model.set_discount(discount)
        model.set_point(point)
        model.set_timezone(timezone)
        model.set_price_type(price.get("type"))

        pb = ParkingAmountBuilder(model=model)
        pb = pb.build()

        assert pb.get("grace_period") == False
        assert pb.get("total_hours") == 37
        assert pb.get("total_amount") == 13000
        assert pb.get("amount") == 13000
